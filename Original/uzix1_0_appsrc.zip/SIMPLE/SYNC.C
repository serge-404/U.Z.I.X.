/* sync.c
 */
#include <unistd.h>

int main(void) {
	return sync();
}
