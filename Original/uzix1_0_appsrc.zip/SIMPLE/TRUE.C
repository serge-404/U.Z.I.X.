/* true.c
 */
int main() {
	return 0;
}
