
#ifndef FA_FA_H
#define FA_FA_H

#include "facommon.h"

#define HDR_BASIC  0
#define HDR_UZIX   1
#define HDR_MSXDOS 2
#define HDR_RAW    3

#define MACRO_OFF       0
#define MACRO_RECORDING 1
#define MACRO_EXPANDING 2

#define SWARNING 0
#define SERROR   1
#define SFATAL   2

#define OOM           3
#define DJNZW1        4
#define TRAILER       5
#define CERANGE       6
#define BORIGIN       7
#define WCYCLIC       8
#define SEMANTIC      9
#define HMACRO       10
#define BADLABEL     11
#define MISSINGPAR   12
#define JRCOND       13
#define NOSOURCE     14
#define NOENDR       15
#define NOENDM       16
#define INVINDEX     17
#define MISNUMBER    18
#define KABOOM       19
#define FNEXPECT     20
#define NONEST       21
#define RLOW         22
#define LATEHEADER   23
#define LOCKHEADER   24
#define BACKORG      25
#define WRGSTUFF     26

struct Param {
  int present;
  int reference; /* (%HL) instead of %HL */
  int reg;
  i32b imm;
  int label;
  int cflag;
  char lb_name[64];
};

struct Macro {
  char ident[64];
  char *mcode;
  int  sz;
};

struct AFile {
  char *name;
  int  absolute;
};

/* errors */
void resume_line();
void failure();
void complain(int severity);
void canned_error(int can,int severity);
void print_error(char *cn);

/* machine code output */
void asmout1(unsigned char v);
void asmout2(unsigned char v, unsigned char w);
void asmout4(unsigned char v, unsigned char w, unsigned char x,
	     unsigned char z);
void asmoutn(int count,unsigned char v);
void asmout_le_address(int address);

/* input file parsing */
int    clear_comments(char *s);
char * parse_param(char *p,int index);
void   parse_opcode();
int    get_register(char *s);
int    get_condflag(char *s);
void   reset_par();
char   myupper(char c);
char * get_next_line(char *dest,int limit);
FILE * fopen_incpath(int i,char *name);

/* directives */
void parse_header(char *p);
void parse_origin(char *p);
void parse_ds(char *p);
void parse_db(char *p);
void parse_dw(char *p);
void parse_da(char *p);
void parse_empty(char *p);
void parse_def(char *p);
void do_align(char *p);
void begin_record_macro(char *p);
void end_record_macro();
int  get_macro(char *ident);
void expand_macro(char *p);
void parse_repeat(char *p);
void parse_endr();
void parse_forget(char *p);
void parse_append(char *p);
void add_append(char *p);
void parse_include(char *p);

/* the real thing */
void assemble_file();
int  assemble_half1();
int  assemble_half2();

void assemble_cp_like(unsigned char b1,unsigned char b2,int *status);
void assemble_rlc_like(unsigned char b1,int *status);
void assemble_ld(int *status);
void assemble_add_like(unsigned char b1,int *status);
void assemble_sub_like(unsigned char b1,int *status);
void assemble_bit_like(unsigned char b1,int *status);
void resolve_references();
void assemble_appends();

/* binary header */
void fill_header();
void basic_header();
void uzix_header();

/* sanity checks */
void param_sanity_test(int index);
void ensure_imm(int index);
void range_check(i32b val,i32b min,i32b max);

/* db */
void run_fadb();
void close_fadb();

#ifndef FA_C
extern char err_msg[384];
extern i32b pc;
extern i32b origin;
extern int econtext;
extern FILE *todb, *fromdb;
extern char *blank;
extern char *newline;
extern int Trace;
#endif /* FA_C */

#endif /* FA_FA_H */

