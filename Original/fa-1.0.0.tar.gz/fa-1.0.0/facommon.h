
#ifndef FACOMMON_H
#define FACOMMON_H 1

#ifdef FOCA_XCOMP
  typedef int i32b;
#else
  typedef long i32b;
#endif

void write_int(FILE *f,i32b v);
char *consume_ident(char *s);
char *consume_whitespace(char *s);
char *parse_number(char *s,i32b *dest);
char escape_of(char s);

#ifndef FACOMMON_C
extern char token[64];
#endif

#endif
