
/* comon functions between fa and fadb */

#define FACOMMON_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#include "facommon.h"

char token[64];

void write_int(FILE *f,i32b v) {
  i32b d,ll;
  char ms=1;
  char a[2];

  a[1]=0;

  if (v<0)  { fwrite("-",1,1,f); v=-v; }
  if (v==0) { fwrite("0",1,1,f); return; }

  for(ll=10000;ll;ll/=10) {
    d=v/ll;
    v-=d*ll;
    if ( (d) || (!ms) ) {
      a[0]='0'+d;
      fwrite(a,1,1,f);
      ms=0;
    }
  }
}

char *consume_whitespace(char *s) {
  for(;*s;s++)
    switch(*s) {
    case ' ':
    case '\t':
      continue;
    default:
      goto cw_out;
    }
 cw_out:
  return s;
}

char *consume_ident(char *s) {
  char c, *t;
  int l=0;
  for(t=token;*s;s++) {
    c=*s;
    if (l==63)
      goto ci_out;
    if (
	((c>='A')&&(c<='Z')) ||
	((c>='a')&&(c<='z')) ||
	((c>='0')&&(c<='9')&&(l>0)) ||
	(c=='_')
	) {
      *(t++)=c;
      ++l;
    } else
      goto ci_out;    
  }
 ci_out:
  *t=0;

  if (!l)
    token[0]=0;

  return s;
}

char *parse_number(char *s,i32b *dest) {
  char c,tmp[16],dig=0;
  int i,sinal=0;
  i32b val,base=10,posval;

  switch(*s) {
  case 0:   exit(2);
  case '+': ++s; break;
  case '-': sinal=1; ++s; break;
  case '$': base=16; ++s; break;
  case '#': base=2; ++s; break;
  case '\'':
    c=*(++s);
    if (c=='\\') {
      ++s;
      c=escape_of(*s);
    } else
      if (!c) goto badchar;
    if ( (*(++s)) != '\'' ) goto badchar;
    ++s;
    *dest=c;
    return s;
  }

  for(i=0;i<16;i++)
    tmp[i]=0;

  for(;*s;s++) {
    c=(char)toupper(*s);
    if ((c>='0')&&(c<='9')) {
      tmp[(int)(dig++)]=c-'0';
      continue;
    }
    if ((base==16)&&(c>='A')&&(c<='F')) {
      tmp[(int)(dig++)]=10+c-'A';
      continue;
    }
    break;
  }

  posval=1;
  for(i=1;i<dig;i++)
    posval*=base;

  val=0;
  for(i=0;i<dig;i++) {
    val+=posval*((int)tmp[i]);
    posval/=base;
  }
  if (sinal) val=-val;
  *dest=val;
  return s;

 badchar:
#ifdef WRGSTUFF
  canned_error(WRGSTUFF,SFATAL);  
#else
  exit(2);
#endif
}

char escape_of(char s) {
  switch(s) {
  case '0': return 0;
  case 'n': return '\n';
  case 'r': return '\r';
  case 't': return '\t';
  case '\\': return '\\';
  case '\'': return '\'';
  case '\"': return '\"';    
  }
#ifdef WRGSTUFF
  strcpy(err_msg,"bad character escape");
  complain(SFATAL);
#else
  exit(2);
#endif

  return 0;
}
