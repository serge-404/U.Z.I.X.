
#ifndef FA_LABELS_H
#define FA_LABELS_H

#include "facommon.h"

void new_label(char *ident,i32b value,i32b sbegin,i32b send);
int  get_label(char *ident,i32b scope);
void new_label_ref(char *ident,i32b location,i32b offset,char relative);
void fix_label_scopes(i32b correct_end);
void label_forget_prefix(char *prefix,i32b endofscope);
void new_db_entry(char t, char * ident, i32b a,i32b b,i32b v);

#endif
