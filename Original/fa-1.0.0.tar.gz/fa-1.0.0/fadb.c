
/* FA DB -- provides extra table storage via pipes */
/* Author: Felipe Bergo <bergo@seul.org> */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "facommon.h"
#include "fadb.h"

static char *sep=" \t\n\r";

struct Tuple ** tuple_index = 0;
int tuple_count = 0;
int index_size = 0;

int cursor[6]={0,0,0,0,0,0};

void oom() {
  fwrite("out of memory\n",1,14,stderr);
  exit(2);
}

void syntax() {
  fwrite("bad query\n",1,10,stderr);
  exit(2);
}

void store(struct Tuple *n) {
  if (index_size == tuple_count) {
    index_size+=64;
    if (tuple_index)
      tuple_index = (struct Tuple **) realloc(tuple_index,
		    index_size * sizeof(struct Tuple *));
    else
      tuple_index = (struct Tuple **) malloc(index_size * 
					     sizeof(struct Tuple *));
    if (!tuple_index) oom();
  }
  tuple_index[tuple_count++]=n;
}

/* Astart L 0 32000 257 */
void append_tuple(char *query) {
  struct Tuple *n;
  char *p;

  n=(struct Tuple *)malloc(sizeof(struct Tuple));
  if (!n) oom();

  p=consume_ident(query);
  if (! token[0]) syntax();

  n->ident=(char *)malloc(strlen(token)+1);
  if (!n->ident) oom();

  strcpy(n->ident,token);
  
  p=consume_whitespace(p);
  p=consume_ident(p);
  if (! token[0]) syntax();
  n->t_type = token[0];

  p=consume_whitespace(p);
  p=parse_number(p,&(n->bound_a));

  p=consume_whitespace(p);
  p=parse_number(p,&(n->bound_b));

  p=consume_whitespace(p);
  p=parse_number(p,&(n->value));

  store(n);  
}

/* Gstart L 30000 */
void get_tuple(char *query) {
  char ident[128], *p;
  char qtype;
  i32b val;
  int i;

  p=consume_ident(query);
  if (!token[0]) syntax();

  strcpy(ident,token);

  p=consume_whitespace(p);
  p=consume_ident(p);
  if (! token[0]) syntax();
  qtype=token[0];

  p=consume_whitespace(p);
  p=parse_number(p,&val);

  for(i=0;i<tuple_count;i++) {
    if ( tuple_index[i]->t_type == qtype )
      if ( (val >= tuple_index[i]->bound_a) &&
	   (val <= tuple_index[i]->bound_b) )
	if (!strcmp(ident,tuple_index[i]->ident)) {
	  write_int(stdout,tuple_index[i]->value);
	  fwrite("\n",1,1,stdout);
	  return;
	}
  }

  fwrite("*\n",1,2,stdout);
}

void reset_cursor(char c) {
  int i;
  i=c-'1';
  if ((i<0)||(i>5)) return;
  cursor[i]=0;
}

void load_cursor(char c,char t) {
  int i;
  struct Tuple *tp;
  i=c-'1';
  if ((i<0)||(i>5)) goto load_fail;

  while(1) {
    if (cursor[i] >= tuple_count) goto load_fail;
    if (tuple_index[cursor[i]]->t_type != t) { ++cursor[i]; continue; }
    tp=tuple_index[cursor[i]];
    cursor[i]++;
    fwrite(tp->ident,1,strlen(tp->ident),stdout);
    fwrite(" ",1,1,stdout);
    write_int(stdout,tp->bound_a);
    fwrite(" ",1,1,stdout);
    write_int(stdout,tp->bound_b);
    fwrite(" ",1,1,stdout);
    write_int(stdout,tp->value);
    fwrite("\n",1,1,stdout);
    return;
  }

 load_fail:
  fwrite("*\n",1,2,stdout);
}

void fix_end_scopes(char t,char *s) {
  i32b v;
  int i;

  parse_number(s,&v);
  
  for(i=0;i<tuple_count;i++)
    if (tuple_index[i]->t_type == t)
      if (tuple_index[i]->bound_b == 0)
	tuple_index[i]->bound_b=v;
}

void forget_scope(char t,char *s) {
  unsigned int v;
  char prefix[64],*p;
  struct Tuple *tp;
  int i,j;

  p=consume_ident(s);
  strcpy(prefix,token);
  j=strlen(prefix);

  p=consume_whitespace(p);
  parse_number(p,&v);

  for(i=0;i<tuple_count;i++) {
    tp=tuple_index[i];

    if (tp->t_type == t)
      if ( (tp->bound_b >= v) && (tp->bound_a <= v) )
	if (!strncmp(tp->ident,prefix,j))
	  tp->bound_b=v;
  }
}

void dump_table() {
  FILE *f;
  int i;

  f=fopen("fadb.log","a");
  if (!f) return;

  for(i=0;i<tuple_count;i++) {
    fwrite(tuple_index[i]->ident,1,strlen(tuple_index[i]->ident),f);
    fwrite(" ",1,1,f);
    write_int(f,tuple_index[i]->bound_a);
    fwrite(" ",1,1,f);
    write_int(f,tuple_index[i]->bound_b);
    fwrite(" ",1,1,f);
    write_int(f,tuple_index[i]->value);
    fwrite("\n",1,1,f);
  }
  fclose(f);
}

int main(int argc, char **argv) {
  char aux[128];
  FILE *log=0;

  setbuf(stdin,0);
  setbuf(stdout,0);

  fwrite("hello from fadb\n",1,16,stdout);

  while(fgets(aux,127,stdin)) {

    if (argc >= 2)
      log=fopen("fadb.log","a");
    if (log) {
      fwrite(aux,1,strlen(aux),log);
      fclose(log);
    }
    
    switch(aux[0]) {
    case 'A': append_tuple(aux+1); break;
    case 'E': fix_end_scopes(aux[1],aux+2); break;
    case 'F': forget_scope(aux[1],aux+2); break;
    case 'G': get_tuple(aux+1); break;
    case 'R': reset_cursor(aux[1]); break;
    case 'L': load_cursor(aux[1],aux[2]); break;
    case 'Q': if (argc>=2) dump_table(); goto getout;
    }
  }

 getout:
  return 0;
}
