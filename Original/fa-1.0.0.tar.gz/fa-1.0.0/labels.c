
#define LABELS_C

#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include "fa.h"
#include "labels.h"

void new_db_entry(char t, char * ident, i32b a, i32b b,i32b v) {
  char dbcmd[72],ts[4];

  ts[0]=' '; ts[1]=t; ts[2]=' '; ts[3]=0;

  strcpy(dbcmd,"A");
  strcat(dbcmd,ident);
  strcat(dbcmd,ts);

  fwrite(dbcmd,1,strlen(dbcmd),todb);

  write_int(todb,a);
  fwrite(blank,1,1,todb);
  write_int(todb,b);
  fwrite(blank,1,1,todb);
  write_int(todb,v);
  fwrite(newline,1,1,todb);
}

void new_label_ref(char *ident,i32b location,i32b offset,char relative)
{
  new_db_entry('R',ident,location,offset,relative);
}

void new_label(char *ident,i32b value,i32b sbegin,i32b send)
{
  char dbcmd[72];

  if (get_label(ident,pc+origin)!=-1) {
    strcpy(err_msg,"duplicate label: ");
    strcat(err_msg,ident);
    complain(SFATAL);
  }

  new_db_entry('L',ident,sbegin,send,value);
}

int  get_label(char *ident,i32b scope) {
  char dbcmd[72],*p;
  i32b rv;

  strcpy(dbcmd,"G");
  strcat(dbcmd,ident);
  strcat(dbcmd," L ");
  fwrite(dbcmd,1,strlen(dbcmd),todb);
  write_int(todb,scope);
  fwrite(newline,1,1,todb);

  if (Trace) {
    fwrite("TL> ",1,4,stderr);
    fwrite(dbcmd,1,strlen(dbcmd),stderr);
    write_int(stderr,scope);
    fwrite(newline,1,1,stderr);
  }

  if (!fgets(dbcmd,71,fromdb)) return -1;

  if (Trace) {
    fwrite("TL> ",1,4,stderr);
    fwrite(dbcmd,1,strlen(dbcmd),stderr);
  }

  if (dbcmd[0]=='*') return -1;

  for(p=dbcmd;*p;p++)
    if (*p < 32) { *p=0; break; }
  rv=(int)(atol(dbcmd) & 0xffff);

  /*  fprintf(stderr,"label %s = $%x\n",ident,rv); */
  
  return(rv);
}

void fix_label_scopes(i32b correct_end) {
  char dbcmd[72];
  strcpy(dbcmd,"EL");
  fwrite(dbcmd,1,strlen(dbcmd),todb);
  write_int(todb,correct_end);
  fwrite(newline,1,1,todb);
}

void label_forget_prefix(char *prefix,i32b endofscope) {
  char dbcmd[72];

  if (prefix[0]==0) {
    canned_error(MISSINGPAR,SERROR);
    return;
  }

  strcpy(dbcmd,"FL");
  strcat(dbcmd,prefix);
  strcat(dbcmd,blank);
  fwrite(dbcmd,1,strlen(dbcmd),todb);  
  write_int(todb,endofscope);
  fwrite(newline,1,1,todb);
}

