
/* focadb.h */


#include "facommon.h"

struct Tuple {
  char *ident;
  char t_type;
  i32b bound_a;
  i32b bound_b;
  i32b value;
};

/* prototypes */

void oom();
void syntax();
void store(struct Tuple *n);
void append_tuple(char *query);
void get_tuple(char *query);
void reset_cursor(char c);
void load_cursor(char c, char t);

