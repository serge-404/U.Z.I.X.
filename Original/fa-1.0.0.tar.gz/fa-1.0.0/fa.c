/*  =========================================================================

    FOCA - Fudeba: Optimizer, Compiler and Assembler
  
    fa - fudeba assembler for the Z80
    http://foca.sourceforge.net

    (C) 2001 Felipe Bergo <bergo@seul.org>
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330,Boston, MA 02111-1307 USA

    =========================================================================

    working directives: header origin org db ds dz dw
                        define def align macro endm x
                        empty rept repeat endr forget
			append include da

    ====================================================================== */

#define FA_C
#define VERSION "1.0.0"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> /* uses unlink() only */

#include "fa.h"
#include "labels.h"
#include "facommon.h"

/* -------------- globals -------------- */

int Verbose = 1;
int Trace = 0;

FILE *fo = 0,*fi = 0;

FILE *todb = 0, *fromdb = 0;

int  err_count = 0;
int  warn_count = 0;
int  econtext=0;
char err_msg[128];
char src_file[128];
char ofile[128];
int  lnum = 0;

int  opcode=0;

i32b  origin=0xC000;
i32b  pc=0;
i32b  hdr_size=0;
i32b  program_size=0;

i32b  scope_b=0, scope_e=0xffff;

struct Repeat {
  char active;
  unsigned char count;
  unsigned long start;
} repeat={0,0,0};

char  header_type=HDR_BASIC;
char  lock_header=0;

/* opcode table */
static char *oc_table[68]={
  "ADC","ADD","AND","BIT","CALL","CCF","CP","CPD","CPDR","CPI",    /*  0-9  */
  "CPIR","CPL","DAA","DEC","DI","DJNZ","EI","EX","EXX","HALT",     /* 10-19 */
  "IM","IN","INC","IND","INDR","INI","INIR","JP","JR","LD",        /* 20-29 */
  "LDD","LDDR","LDI","LDIR","NEG","NOP","OR","OTDR","OTIR","OUT",  /* 30-39 */
  "OUTD","OUTI","POP","PUSH","RDL","RES","RET","RETI","RETN","RL", /* 40-49 */
  "RLA","RLC","RLCA","RLD","RR","RRA","RRC","RRCA","RRD","RST",    /* 50-59 */
  "SBC","SCF","SET","SLA","SRA","SRL","SUB","XOR"                  /* 60-67 */
};
int oc_count=68;

/* registers
   -1   0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16
   n/a  B C D E H L A F R I BC DE HL IX IY SP AF
*/
static char *regnames[17]={
  "B","C","D","E","H","L","A","F","R","I",
  "BC","DE","HL","IX","IY","SP","AF" };

/* cond flags: NZ Z NC C PO PE P M */
static char *condflags[8]={"NZ","Z","NC","C","PO","PE","P","M"};

int d_count=21;
static char *directives[21]={
  /* 0  */ "header","origin","org","db","ds","dz","dw",
  /* 7  */ "define","def","align","macro","endm","x",
  /* 13 */ "empty","rept","repeat","endr","forget","append",
  /* 19 */ "include","da"
};

char inc_count=5;
static char *inc_path[5]={
  "/include/asm/","/usr/include/asm/","/usr/local/include/asm/",
  "/foca/asm/","/opt/foca/asm/"
};

static char *err_repo[27]={
  "warning",
  "error",
  "fatal error",
  "out of memory",
  "fudeba, use a label",
  "excess characters ignored",
  "constant out of range",
  "origin below $8000 in BASIC mode",
  "cyclic reference",
  "semantic error in instruction usage",
  "macro text exceeds 1 KB",
  "bad label syntax",
  "parameter(s) are required",
  "JR accepts Z NZ C NC only",
  "no source files specified",
  "unbalanced .rept / .endr",
  "unbalanced .macro / .endm",
  "invalid indexing",
  "numeric value expected",
  "internal error",
  "file name expected",
  "cannot nest this",
  "repeat count too low",
  "header directive must precede first instruction",
  "can't change header (again)",
  "origin directive points backwards",
  "the wrong stuff, in the wrong place"
};

char *blank = " ";
char *newline = "\n";

struct Param par[2];
int parcount;

struct Macro ** m_index=0;
int m_index_size=0;
int m_count=0;

struct AFile ** a_index=0;
int a_index_size=0;
int a_count=0;

char macro_state=0; /* 0=none 1=recording 2=expanding */
char *macrop; /* cursor on macro being expanded */

/* ============================================================

                           ASSEMBLING

   ============================================================ */

void assemble_file() {
  char line[256];
  char *p;
  int lb_hint, req_param, cry;
  int i;

  while(get_next_line(line,255)) {

    if (Trace) {
      fwrite("T> ",1,3,stderr);
      fwrite(line,1,strlen(line),stderr);
    }
    
    if (macro_state!=MACRO_EXPANDING)
      ++lnum;
    cry=0;

    lb_hint=clear_comments(line);
    p=consume_whitespace(line);

    if (!*p)
      continue;

    if (macro_state==MACRO_RECORDING) {
      if (!strncmp(p,".endm",5)) {
	end_record_macro();
	continue;
      }
      strcat(p,newline);
      m_index[m_count-1]->sz += strlen(p);
      if (m_index[m_count-1]->sz > 1024)
	canned_error(HMACRO,SFATAL);
      strcat(m_index[m_count-1]->mcode,p);
      continue;
    }

    if (lb_hint) {
      p=consume_ident(p);
      p=consume_whitespace(p);

      if (*p != ':') {
	canned_error(BADLABEL,SERROR);
	continue;
      }
      
      new_label(token,pc+origin,scope_b,scope_e);
      ++p;
      
      p=consume_whitespace(p);      
    }

    if (!*p)
      continue;

    /* alternative .x syntax */
    if (*p == '[') {
      expand_macro(p+1);
      continue;
    }

    /* get opcode or directive */

    if (*p == '.') { /* directive */
      p=consume_ident(++p);

      for(i=0;i<d_count;i++)
	if (!strcmp(token,directives[i])) {
	  switch(i) {
	  case 0:  /* header */ parse_header(p); break;
	  case 1: case 2: /* org origin */ parse_origin(p); break;
	  case 3:  /* db */ parse_db(p); break;
	  case 4:  /* ds */ parse_ds(p); break;
	  case 5:  /* dz */ parse_ds(p); asmout1(0); break;
	  case 6:  /* dw */ parse_dw(p); break;
	  case 7: case 8: /* def define */ parse_def(p); break;
	  case 9:  /* align  */ do_align(p); break;
	  case 10: /* macro  */ begin_record_macro(p); break;
	  case 11: /* endm   */ end_record_macro(); break; /* !!! */
	  case 12: /* x      */ expand_macro(p); break;
	  case 13: /* empty  */ parse_empty(p); break;
	  case 14: case 15: /* rept / repeat */ parse_repeat(p); break;
	  case 16: /* endr   */ parse_endr(); break;
	  case 17: /* forget */ parse_forget(p); break;
	  case 18: /* append */ parse_append(p); break;
	  case 19: /* include */ parse_include(p); break;
	  case 20: /* da */ parse_da(p); break;
	  }
	  break;
	}

      if (i==d_count) {     
	strcpy(err_msg,"skipping unknown directive ");
	strcat(err_msg,token);
	complain(SERROR);
      }
      continue;

    } else {         /* opcode */
      p=consume_ident(p);
      parse_opcode();

      req_param=0;

      switch(opcode) {
      case 5:  asmout1(0x3f); break; /* ccf */
      case 7:  asmout2(0xed,0xa9); break; /* cpd */
      case 8:  asmout2(0xed,0xb9); break; /* cpdr */
      case 9:  asmout2(0xed,0xa1); break; /* cpi */
      case 10: asmout2(0xed,0xb1); break; /* cpir */
      case 11: asmout1(0x2f); break; /* cpl */
      case 12: asmout1(0x27); break; /* daa */	
      case 14: asmout1(0xf3); break; /* di */
      case 16: asmout1(0xfb); break; /* ei */
      case 18: asmout1(0xd9); break; /* exx */
      case 19: asmout1(0x76); break; /* halt */	
      case 23: asmout2(0xed,0xaa); break; /* ind */
      case 24: asmout2(0xed,0xba); break; /* indr */
      case 25: asmout2(0xed,0xa2); break; /* ini */
      case 26: asmout2(0xed,0xb2); break; /* inir */
      case 30: asmout2(0xed,0xa8); break; /* ldd */
      case 31: asmout2(0xed,0xb8); break; /* lddr */
      case 32: asmout2(0xed,0xa0); break; /* ldi */
      case 33: asmout2(0xed,0xb0); break; /* ldir */
      case 34: asmout2(0xed,0x44); break; /* neg */
      case 35: asmout1(0x00); break; /* nop */	
      case 37: asmout2(0xed,0xbb); break; /* otdr */
      case 38: asmout2(0xed,0xb3); break; /* otir */
      case 40: asmout2(0xed,0xab); break; /* outd */
      case 41: asmout2(0xed,0xa3); break; /* outi */
      case 44: asmout2(0xed,0x6f); break; /* rld / rdl */
      case 47: asmout2(0xed,0x4d); break; /* reti */
      case 48: asmout2(0xed,0x45); break; /* retn */
      case 50: asmout1(0x17); break; /* rla */
      case 52: asmout1(0x07); break; /* rlca */
      case 53: asmout2(0xed,0x6f); break; /* rld / rdl */
      case 55: asmout1(0x1f); break; /* rra */
      case 57: asmout1(0x0f); break; /* rrca */
      case 58: asmout2(0xed,0x67); break; /* rrd */
      case 61: asmout1(0x37); break; /* scf */
      default: req_param=1;
      }

      p=consume_whitespace(p);
      if ( (*p) && (!req_param) )
	canned_error(TRAILER,SWARNING);

      if (!req_param)
	continue;      
      
      reset_par();

      if (! *p) {
	if (opcode==46) { /* unconditional RET */
	  asmout1(0xc9);
	  continue;
	}

	canned_error(MISSINGPAR,SERROR);
	continue;
      }

      p=parse_param(p,0);
      param_sanity_test(0);

      p=consume_whitespace(p);
      
      if (*p == ',') {
	p=consume_whitespace(p+1);
	p=parse_param(p,1);
	param_sanity_test(1);
	p=consume_whitespace(p);
	if (*p)
	  canned_error(TRAILER,SWARNING);
      }

      if (opcode < 27)
	cry = assemble_half1();
      else
	cry = assemble_half2();

      if (cry)
	canned_error(SEMANTIC,SFATAL);

    } /* else (treat opcodes) */

  } /* while fgets */

}

int  assemble_half1() {
  int cry=0;
  int ri;

  switch(opcode) {
  case 0: /* ADC */
    assemble_add_like(0x88,&cry);
    break;
  case 1: /* ADD */
    assemble_add_like(0x80,&cry);
    break;
  case 2: /* AND */
    assemble_cp_like(0xa0,0xe6,&cry);
    break;
  case 3: /* BIT */
    assemble_bit_like(0x40,&cry);
    break;
  case 4: /* CALL */
    if ((par[0].cflag>=0)&&(par[1].present)) {
      asmout1(0xc4 + 8*par[0].cflag);
      if (par[1].label) {
	new_label_ref(par[1].lb_name,pc,par[1].imm,0);
	asmout2(0,0);
      } else {
	ensure_imm(1);
	asmout_le_address(par[1].imm);
      }
      break;
    }
    if (par[0].cflag<0) {
      asmout1(0xcd);
      if (par[0].label) {
	new_label_ref(par[0].lb_name,pc,par[0].imm,0);
	asmout2(0,0);
      } else {
	ensure_imm(0);
	asmout_le_address(par[0].imm);
      }
      break;
    }
    cry=1;
    break;
  case 6: /* CP */
    assemble_cp_like(0xb8,0xfe,&cry);
    break;
  case 13: /* DEC */
    if (par[0].reg<0) { cry=1; break; }
    if (par[0].reference) {
      switch(par[0].reg) {
      case 12: asmout1(0x35); break;
      case 13: asmout2(0xdd,0x35); asmout1(par[0].imm); break; 
      case 14: asmout2(0xfd,0x35); asmout1(par[0].imm); break; 
      default: cry=1;
      }
    } else {
      if (par[0].reg<=6) { 
	ri=par[0].reg; if (ri==6) ++ri;
	asmout1(0x05+8*ri);
	break;
      }
      switch(par[0].reg) {
      case 10: asmout1(0x0b); break;
      case 11: asmout1(0x1b); break;
      case 12: asmout1(0x2b); break;
      case 13: asmout2(0xdd,0x2b); break;
      case 14: asmout2(0xfd,0x2b); break;
      case 15: asmout1(0x3b); break;
      default: cry=1;
      }
    }
    break;
  case 15: /* DJNZ */
    asmout1(0x10);
    if (par[0].label) {
      asmout1(0);
      new_label_ref(par[0].lb_name,pc-1,par[0].imm,1);
    } else {
      ensure_imm(0);
      asmout1(0xff&par[0].imm);
      canned_error(DJNZW1,SWARNING);
    }
    break;
  case 17: /* EX */
    if ((par[0].reg==16)&&(!par[0].reference)) {
      asmout1(0x08);
      break;
    }
    if ((par[0].reg==11)&&(par[1].present)&&(par[1].reg==12)&&
	(!par[0].reference)&&(!par[1].reference)) {
      asmout1(0xeb);
      break;
    }
    if ((par[0].reg==15)&&(par[0].reference)&&(par[1].present)&&
	(!par[1].reference)) {
      switch(par[1].reg) {
      case 12: asmout1(0xe3); break;
      case 13: asmout2(0xdd,0xe3); break;
      case 14: asmout2(0xfd,0xe3); break;
      default: cry=1;
      }
      break;
    }
    cry=1;
    break;
  case 20: /* IM */
    ensure_imm(0);
    switch(par[0].imm) {
    case 0: asmout2(0xed,0x46); break;
    case 1: asmout2(0xed,0x56); break;
    case 2: asmout2(0xed,0x5e); break;
    default: cry=1;
    }
    break;
  case 21: /* IN */
    if ((par[1].present)&&(par[1].reg==1)&&(par[1].reference)&&
	(par[0].reg>=0)&&(par[0].reg<=6)&&(!par[0].reference)) {
      ri=par[0].reg; if (ri==6) ++ri;
      asmout2(0xed,0x40+8*ri);
      break;
    }
    if ((par[1].present)&&(par[1].reg<0)&&(par[1].cflag<0)&&
	(!par[1].label)&&(par[0].reg==6)&&(!par[0].reference)) {
      range_check(par[1].imm,0,255);
      asmout2(0xdb,par[1].imm);
      break;
    }
    cry=1;
    break;
  case 22: /* INC */
    if (par[0].reg<0) { cry=1; break; }
    if (par[0].reference) {
      switch(par[0].reg) {
      case 12: asmout1(0x34); break;
      case 13: asmout2(0xdd,0x34); asmout1(par[0].imm); break; 
      case 14: asmout2(0xfd,0x34); asmout1(par[0].imm); break; 
      default: cry=1;
      }
    } else {
      if (par[0].reg<=6) { 
	ri=par[0].reg; if (ri==6) ++ri;
	asmout1(0x04+8*ri);
	break;
      }
      switch(par[0].reg) {
      case 10: asmout1(0x03); break;
      case 11: asmout1(0x13); break;
      case 12: asmout1(0x23); break;
      case 13: asmout2(0xdd,0x23); break;
      case 14: asmout2(0xfd,0x23); break;
      case 15: asmout1(0x33); break;
      default: cry=1;
      }
    }
    break;
  }
  return cry;
}

int  assemble_half2() {
  int cry=0;
  int ri;

  switch(opcode) {
  case 27: /* JP */
    if (par[0].reference) {
      switch(par[0].reg) {
      case 12: asmout1(0xe9); break;
      case 13: asmout2(0xdd,0xe9); break;
      case 14: asmout2(0xfd,0xe9); break;
      default: cry=1;
      }
      break;
    }
    if ((par[0].cflag>=0)&&(par[1].present)) {
      asmout1(0xc2 + 8*par[0].cflag);
      if (par[1].label) {
	new_label_ref(par[1].lb_name,pc,par[1].imm,0);
	asmout2(0,0);
      } else {
	ensure_imm(1);
	asmout_le_address(par[1].imm);
      }
      break;
    }
    if (par[0].cflag<0) {
      asmout1(0xc3);
      if (par[0].label) {
	new_label_ref(par[0].lb_name,pc,par[0].imm,0);
	asmout2(0,0);
      } else {
	ensure_imm(0);
	asmout_le_address(par[0].imm);
      }
      break;
    }
    cry=1;
    break;
  case 28: /* JR */
    if ((par[0].cflag>=0)&&(par[1].present)) {
      if (par[0].cflag>3)
	canned_error(JRCOND,SFATAL);
      asmout1(0x20+8*par[0].cflag);
      if (par[1].label) {
	asmout1(0);
	new_label_ref(par[1].lb_name,pc-1,par[1].imm,1);
      } else {
	ensure_imm(1);
	range_check(par[1].imm,-128,127);
	asmout1(0xff&par[1].imm);
	canned_error(DJNZW1,SWARNING);
      }
      break;
    }	
    if (par[0].label) {
      asmout2(0x18,0x00);
      new_label_ref(par[0].lb_name,pc-1,par[0].imm,1);
    } else {
      ensure_imm(0);
      range_check(par[0].imm,-128,127);
      asmout1(0xff&par[0].imm);
      canned_error(DJNZW1,SWARNING);
    }
    break;
  case 29: /* LD */
    assemble_ld(&cry);
    break;
  case 36: /* OR */
    assemble_cp_like(0xb0,0xf6,&cry);
    break;
  case 39: /* OUT */
    if ((par[1].present)&&(par[0].reg==1)&&(par[0].reference)&&
	(par[1].reg>=0)&&(par[1].reg<=6)&&(!par[1].reference)) {
      ri=par[1].reg; if (ri==6) ++ri;
      asmout2(0xed,0x41+8*ri);
      break;
    }
    if ((par[1].present)&&(par[0].reg<0)&&(par[0].cflag<0)&&
	(!par[0].label)&&(par[1].reg==6)&&(!par[1].reference)) {
      range_check(par[0].imm,0,255);
      asmout2(0xd3,par[0].imm);
      break;
    }
    cry=1;	
    break;
  case 42: /* POP */
    if (par[0].reference) cry=1;
    switch(par[0].reg) {
    case 10: asmout1(0xc1); break;
    case 11: asmout1(0xd1); break;
    case 12: asmout1(0xe1); break;
    case 13: asmout2(0xdd,0xe1); break;
    case 14: asmout2(0xfd,0xe1); break;
    case 16: asmout1(0xf1); break;
    default: cry=1;
    }
    break;
  case 43: /* PUSH */
    if (par[0].reference) cry=1;
    switch(par[0].reg) {
    case 10: asmout1(0xc5); break;
    case 11: asmout1(0xd5); break;
    case 12: asmout1(0xe5); break;
    case 13: asmout2(0xdd,0xe5); break;
    case 14: asmout2(0xfd,0xe5); break;
    case 16: asmout1(0xf5); break;
    default: cry=1;
    }
    break;
  case 45: /* RES */
    assemble_bit_like(0x80,&cry);
    break;
  case 46: /* RET cond */
    if (par[0].cflag < 0)
      canned_error(SEMANTIC,SFATAL);
    asmout1(0xc0+8*par[0].cflag);
    break;
  case 49: /* RL */
    assemble_rlc_like(0x10,&cry);
    break;
  case 51: /* RLC */
    assemble_rlc_like(0,&cry);
    break;
  case 54: /* RR */
    assemble_rlc_like(0x18,&cry);
    break;
  case 56: /* RRC */
    assemble_rlc_like(8,&cry);
    break;
  case 59: /* RST # */
    ensure_imm(0);
    if ((par[0].imm<0)||(par[0].imm>56)||(par[0].imm%8))
      canned_error(SEMANTIC,SFATAL);
    asmout1(0xc7+par[0].imm);
    break;
  case 60: /* SBC */
    assemble_sub_like(0x98,&cry);
    break;
  case 62: /* SET */
    assemble_bit_like(0xc0,&cry);
    break;
  case 63: /* SLA */
    assemble_rlc_like(0x20,&cry);
    break;
  case 64: /* SRA */
    assemble_rlc_like(0x28,&cry);
    break;
  case 65: /* SRL */
    assemble_rlc_like(0x38,&cry);
    break;
  case 66: /* SUB */
    assemble_sub_like(0x90,&cry);
    break;
  case 67: /* XOR */
    assemble_cp_like(0xa8,0xee,&cry);
    break;
  default:
    cry=1;
  }
  return cry;
}


/* bit set res */
void assemble_bit_like(unsigned char b1,int *status) {
  int ri, a;
  if ((par[0].cflag>=0)||
      (par[1].cflag>=0)||
      (par[0].reference)||
      (par[0].label)||
      (par[1].label)||
      (par[0].reg>=0)||
      (par[1].reg<0)) { *status=1; return; }
  
  a=par[0].imm;
  if ((a<0)||(a>7)) { *status=1; return; }

  if ((par[1].reg<=6)&&(!par[1].reference)) {
    ri=par[1].reg; if (ri==6) ++ri;
    
    asmout2(0xcb,b1+8*a+ri);
    return;
  }

  if (par[1].reference) {
    switch(par[1].reg) {
    case 12: asmout2(0xcb,b1+6+8*a); break;
    case 13: asmout4(0xdd,0xcb,par[1].imm,b1+6+8*a); break;
    case 14: asmout4(0xfd,0xcb,par[1].imm,b1+6+8*a); break;
    default: *status=1;
    }
    return;
  }

  *status=1;
}

/* sub sbc */
void assemble_sub_like(unsigned char b1,int *status) {
  int ri1;
  if ((par[0].cflag>=0)||
      (par[1].cflag>=0)||
      (par[0].reference)) { *status=1; return; }

  /* sub %a, reg8 */
  if ((par[0].reg == 6)&&(par[1].reg>=0)&&(par[1].reg<=6)) {
    ri1=par[1].reg;
    if (ri1==6) ++ri1;
    asmout1(b1 + ri1);
    return;
  }

  /* sub %a. (%hl %ix %iy) */
  if ((par[0].reg == 6)&&(par[1].reference)) {
    switch(par[1].reg) {
    case 12: asmout1(b1+6); return;
    case 13: ri1=0xdd; break;
    case 14: ri1=0xfd; break;
    default: *status=1;
    }
    asmout2((unsigned char)ri1,b1+6);
    asmout1(par[1].imm);
    return;
  }

  /* sub %a, imm */
  if ( (par[0].reg == 6) && (par[1].reg < 0) && (!par[1].reference) ) {
    asmout2(b1-0x80+0xd6,par[1].imm);
    return;
  }

  if ((b1<0x98)||(par[1].reference)) { *status=1; return; }

  /* sbc %hl, %bc %de %hl %sp */
  
  if (par[0].reg==12) {
    switch(par[1].reg) {
    case 10: ri1=0x42; break;
    case 11: ri1=0x52; break;
    case 12: ri1=0x62; break;
    case 15: ri1=0x72; break;
    default: *status=1;
    }
    asmout2(0xed,(unsigned char)ri1);
    return;
  }

  *status=1;
}

/* add adc */
void assemble_add_like(unsigned char b1,int *status) {
  int ri1;
  if ((par[0].cflag>=0)||
      (par[1].cflag>=0)||
      (par[0].reference)) { *status=1; return; }
  
  /* add %a, reg8 */
  if ((par[0].reg == 6)&&(par[1].reg>=0)&&(par[1].reg<=6)) {
    ri1=par[1].reg;
    if (ri1==6) ++ri1;
    asmout1(b1 + ri1);
    return;
  }

  /* add %a, (%hl %ix %iy) */
  if ((par[0].reg == 6)&&(par[1].reference)) {
    switch(par[1].reg) {
    case 12: asmout1(b1+6); return;
    case 13: ri1=0xdd; break;
    case 14: ri1=0xfd; break;
    default: *status=1;      
    }
    asmout2((unsigned char)ri1,b1+6);
    asmout1(par[1].imm);
    return;
  }

  /* add %hl, %bc %de %hl %sp */
  if (par[0].reg == 12) {
    switch(par[1].reg) {
    case 10: ri1=0; break;
    case 11: ri1=0x10; break;
    case 12: ri1=0x20; break;
    case 15: ri1=0x30; break;
    default: *status=1;
    }
    if (b1==0x80) asmout1((unsigned char)(9+ri1));
    else asmout2(0xed,(unsigned char)(0x4a+ri1));
    return;
  }

  /* add %a, imm */
  if ( (par[0].reg == 6) && (par[1].reg < 0) && (!par[1].reference) ) {
    asmout2(b1-0x80+0xc6,par[1].imm);
    return;
  }

  if ((b1>0x80)||(par[1].reference)) { *status=1; return; }

  /* add only */
     
  /* add %ix, bc de ix sp */
  if (par[0].reg==13) {
    switch(par[1].reg) {
    case 10: ri1=0x09; break;
    case 11: ri1=0x19; break;
    case 13: ri1=0x29; break;
    case 15: ri1=0x39; break;
    default: *status=1;
    }
    asmout2(0xdd,(unsigned char)ri1);
    return;
  }

  /* add %iy, bc de iy sp */
  if (par[0].reg==14) {
    switch(par[1].reg) {
    case 10: ri1=0x09; break;
    case 11: ri1=0x19; break;
    case 14: ri1=0x29; break;
    case 15: ri1=0x39; break;
    default: *status=1;
    }
    asmout2(0xfd,(unsigned char)ri1);
    return;
  }
     
  *status=1;
}

/* rlc, rrc, rl, rr, sla, sra, srl */
void assemble_rlc_like(unsigned char b1,int *status) {
  if ((par[0].label)||(par[0].cflag>=0)) {
    *status=1;
    return;
  }
  if (par[0].reference) {
    if (par[0].reg == 12) {
      asmout2(0xcb,b1+6);
      return;
    }
    if (par[0].reg == 13) {
      asmout4(0xdd,0xcb,par[0].imm,b1+6);
      return;
    }
    if (par[0].reg == 14) {
      asmout4(0xfd,0xcb,par[0].imm,b1+6);
      return;
    }
    *status=1;
  } else {
    if ( (par[0].reg >=0) && (par[0].reg <= 5) ) {
      asmout2(0xcb,b1+par[0].reg);
      return;
    }
    if (par[0].reg==6) {
      asmout2(0xcb,b1+7);
      return;
    }
    *status=1;
  }
}

/* cp, and, or, xor */
void assemble_cp_like(unsigned char b1,unsigned char b2,int *status) {
  if ((par[0].label)||(par[0].cflag>=0)) {
    *status=1;
    return;
  }
  if (par[0].reference) {
    if (par[0].reg == 12) {
      asmout1(b1+6);
      return;
    }
    if (par[0].reg == 13) {
      asmout2(0xdd,b1+6);
      asmout1(par[0].imm);
      return;
    }
    if (par[0].reg == 14) {
      asmout2(0xfd,b1+6);
      asmout1(par[0].imm);
      return;
    }
    *status=1;    
  } else {
    if ( (par[0].reg >=0) && (par[0].reg <= 5) ) {
      asmout1(b1+par[0].reg);
      return;
    }
    if (par[0].reg==6) {
      asmout1(b1+7);
      return;
    }
    if (par[0].reg < 0) {
      range_check(par[0].imm,-128,255);
      asmout2(b2,par[0].imm);
      return;
    }
    *status=1;
  }  
}

void assemble_ld(int *status) {
  int ri0,ri1;

  if (!par[1].present) { *status=1; return; }
  if (par[0].cflag>=0) { *status=1; return; }
  if (par[1].cflag>=0) { *status=1; return; }

  /* ld reg8, reg8 */
  
  if ((!par[0].reference)&&(!par[1].reference)&&
      (par[0].reg>=0)&&(par[0].reg<=6)&&
      (par[1].reg>=0)&&(par[1].reg<=6)) {
    
    ri0=par[0].reg; if (ri0==6) ++ri0;
    ri1=par[1].reg; if (ri1==6) ++ri1;

    asmout1(0x40 + 0x08*ri0 + ri1); 
    return;
  }

  /* special regs %i, %r */
  if ((!par[0].reference)&&(!par[1].reference)) {
    
    if (par[0].reg == 6) {
      if (par[1].reg == 9) {
	asmout2(0xed,0x57); /* ld a,i */
	return;
      }
      if (par[1].reg == 8) { /* ld a,r */
	asmout2(0xed,0x5f);
	return;
      }
    }

    if (par[1].reg == 6) {
      if (par[0].reg == 9) {
	asmout2(0xed,0x47); /* ld i,a */
	return;
      }
      if (par[0].reg == 8) { /* ld r,a */
	asmout2(0xed,0x4f);
	return;
      }
    }

    if (par[0].reg==15) { /* %sp , direct */
      if (par[1].reg==12) { asmout1(0xf9); return; }
      if (par[1].reg==13) { asmout2(0xdd,0xf9); return; }
      if (par[1].reg==14) { asmout2(0xfd,0xf9); return; }
      if (par[1].reg<0) {
	if (par[1].label) {
	  new_label_ref(par[1].lb_name,pc+1,par[1].imm,0);
	  asmout1(0x31); asmout2(0,0);
	} else {
	  asmout1(0x31);
	  asmout_le_address(par[1].imm);
	}
	return;
      }
      *status=1;
      return;
    } /* ld %sp, direct */

    /* ld reg8, imm */
    if ((par[0].reg>=0)&&(par[0].reg<=6)&&
	(par[1].reg<0)&&(!par[1].label)) {
      range_check(par[1].imm,-128,255);
      ri0=par[0].reg; if (ri0==6) ++ri0;
      asmout2(0x06 + 8*ri0, par[1].imm);
      return;
    }

    /* ld reg16, imm */
    if ((par[0].reg>=10)&&(par[0].reg<=14)&&(par[1].reg<0)) {
      switch(par[0].reg) {
      case 10:
      case 11:
      case 12: asmout1(0x01 + 0x10 * (par[0].reg-10)); break;
      case 13: asmout2(0xdd,0x21); break;
      case 14: asmout2(0xfd,0x21); break;	
      }
      if (par[1].label) {
	new_label_ref(par[1].lb_name,pc,par[1].imm,0);
	asmout2(0,0);
      } else {
	asmout_le_address(par[1].imm);
      }
      return;
    }

    *status=1;
    return;
  } /* no indirections */

  /* left side indirections */
  if ((par[0].reference)&&(!par[1].reference)&&(!par[1].label)) {

    /* ld (%hl) (%ix) (%iy) , -- */
    if ( (par[0].reg >= 12) && (par[0].reg <= 14) ) {
      ri0=0;
      if (par[0].reg==13) { asmout1(0xdd); ri0=1; }
      if (par[0].reg==14) { asmout1(0xfd); ri0=1; }
      
      if (par[1].reg<0) {
	asmout1(0x36);
	if (ri0) asmout1(par[0].imm);
	asmout1(par[1].imm);
	return;
      }
      
      if (par[1].reg>6) {
	*status=1;
	return;
      }

      ri1=par[1].reg;
      if (ri1==6) ++ri1;
      asmout1(0x70 + ri1);
      if (ri0) asmout1(par[0].imm);
      return;
    }

    /* ld (%bc %de), %a */
    if ((par[0].reg==10)||(par[0].reg==11))
      if (par[1].reg==6) {
	asmout1(0x02 + 0x10 * (par[0].reg-10));
	return;
      }

    /* ld (imm), a bc de hl ix iy sp */
    if (par[0].reg<0) {
      switch(par[1].reg) {
      case 6:  asmout1(0x32); break;
      case 10: asmout2(0xed,0x43); break;
      case 11: asmout2(0xed,0x53); break;
      case 12: asmout1(0x22); break;
      case 13: asmout2(0xdd,0x22); break;
      case 14: asmout2(0xfd,0x22); break;
      case 15: asmout2(0xed,0x73); break;
      default: *status=1; return;
      }
      if (par[0].label) {
	new_label_ref(par[0].lb_name,pc,par[0].imm,0);
	asmout2(0,0);
      } else {
	asmout_le_address(par[0].imm);
      }
      return;
    }

    *status=1;
    return;
  }

  /* right side indirections */
  if ((par[1].reference)&&(!par[0].reference)&&(!par[0].label)) {

    /* ld --, (%hl) (%ix) (%iy) , */
    if ( (par[1].reg >= 12) && (par[1].reg <= 14) ) {
      ri1=0;
      if (par[1].reg==13) { asmout1(0xdd); ri1=1; }
      if (par[1].reg==14) { asmout1(0xfd); ri1=1; }
      
      if (par[0].reg>6) {
	*status=1;
	return;
      }

      ri0=par[0].reg;
      if (ri0==6) ++ri0;
      asmout1(0x46 + 8*ri0);
      if (ri1) asmout1(par[1].imm);
      return;
    }

    /* ld %a , (%bc %de) */
    if ((par[1].reg==10)||(par[1].reg==11))
      if (par[0].reg==6) {
	asmout1(0x0a + 0x10 * (par[1].reg-10));
	return;
      }    

    /* ld a bc de hl ix iy sp, (imm) */
    if (par[1].reg<0) {
      switch(par[0].reg) {
      case 6:  asmout1(0x3a); break;
      case 10: asmout2(0xed,0x4b); break;
      case 11: asmout2(0xed,0x5b); break;
      case 12: asmout1(0x2a); break;
      case 13: asmout2(0xdd,0x2a); break;
      case 14: asmout2(0xfd,0x2a); break;
      case 15: asmout2(0xed,0x7b); break;
      default: *status=1; return;
      }
      if (par[1].label) {
	new_label_ref(par[1].lb_name,pc,par[1].imm,0);
	asmout2(0,0);
      } else {
	asmout_le_address(par[1].imm);
      }
      return;
    }

    *status=1;
    return;
  }

  *status=1;
}

void run_fadb() {
  /*  to   from  */
  int p[2],q[2];
  char aux[32];

  if (pipe(p)) {
    strcpy(err_msg,"pipe() failed");
    complain(SFATAL);
  }  

  if (pipe(q)) {
    strcpy(err_msg,"pipe() failed");
    complain(SFATAL);
  }  

  if (!fork()) {
    close(0);
    dup(p[0]);

    close(1);
    dup(q[1]);

    close(p[0]);
    close(q[1]);

    close(p[1]);
    close(q[0]);

    if (Trace) {
      execlp("fadb","fadb","-t",0);
      execlp("./fadb","fadb","-t",0);
      execlp("/usr/bin/fadb","fadb","-t",0);
    } else {
      execlp("fadb","fadb",0);
      execlp("./fadb","fadb",0);
      execlp("/usr/bin/fadb","fadb",0);
    }
    strcpy(err_msg,"execlp() failed");
    complain(SFATAL);
  } else {
    close(p[0]);
    close(q[1]);

    todb=fdopen(p[1],"w");
    fromdb=fdopen(q[0],"r");

    setbuf(todb,0);
    setbuf(fromdb,0);

    if ((!todb)||(!fromdb)) {
      strcpy(err_msg,"huh?!?");
      complain(SFATAL);
    }

    if (!fgets(aux,31,fromdb)) {
      econtext=99;
      canned_error(KABOOM,SFATAL);
    }

    fwrite("fadb>",1,4,stderr);
    fwrite(aux,1,strlen(aux),stderr);
  }  
}

void close_fadb() {
  if (todb) {
    fwrite("Q\n",1,2,todb);
    fclose(todb);
    fclose(fromdb);
    todb=0;
    fromdb=0;
  }
}

/* =======================================================================
   =======================================================================
                                 MAIN
   =======================================================================
   =======================================================================  */
int main(int argc,char **argv) {
  int i,t=-1,sf=0;

  strcpy(ofile,"a.out");
  src_file[0]=0;

  /* parse command line */
  for(i=1;i<argc;i++) {
    if (!strcmp(argv[i],"-q")) { Verbose=0; continue; }
    if (!strcmp(argv[i],"-t")) { Trace=1; continue; }
    
    if ((i+1)==argc) continue;
    
    if (!strcmp(argv[i],"-o")) {
      strcpy(ofile,argv[i+1]);
      t=++i;
      continue;
    }   
  }

  if (Verbose) {
    fwrite("Fudeba Assembler ",1,17,stderr);
    fwrite(VERSION,1,strlen(VERSION),stderr);
    fwrite(" (C)2001 Felipe Bergo\n",1,22,stderr);
  }

  run_fadb();

  fo=fopen(ofile,"w");
  
  if (!fo) {
    strcpy(err_msg,"can't create file ");
    strcat(err_msg,ofile);
    complain(SFATAL);
  }

  for(i=1;i<argc;i++) {
    if ((i!=t)&&(argv[i][0]!='-')) {
      fi=fopen(argv[i],"r");

      if (Verbose) {
	fwrite("assembling ",1,11,stderr);
	fwrite(argv[i],1,strlen(argv[i]),stderr);
	fwrite(newline,1,1,stderr);
      }

      if (!fi) {
	strcpy(err_msg,"can't open file ");
	strcat(err_msg,argv[i]);
	complain(SERROR);
	continue;
      }

      strcpy(src_file,argv[i]);
      lnum=0;

      assemble_file();
      fclose(fi);
      ++sf;
    }
  }

  if (!sf)
    canned_error(NOSOURCE,SFATAL);

  if (a_count)
    assemble_appends();

  if (repeat.active)
    canned_error(NOENDR,SFATAL);

  if (macro_state != MACRO_OFF)
    canned_error(NOENDM,SFATAL);

  src_file[0]=0;

  program_size=pc;
  if (Verbose) {
    fwrite("code size: ",1,11,stderr);
    write_int(stderr,program_size);
    fwrite(" bytes\n",1,7,stderr);
  }

  resolve_references();

  if (err_count)
    failure();

  switch(header_type) {
  case HDR_BASIC:
    basic_header();
    break;
  case HDR_UZIX:
    uzix_header();
    break;
  }

  if (fo) {
    fclose(fo);
    fo=0;
    chmod(ofile,0755);
  }

  if (warn_count)
    resume_line();
  close_fadb();
  exit(0);
}

FILE *fopen_incpath(int i,char *name) {
  int j;
  FILE *f;
  char fname[256], *n;
  int absfn;

  if (name) {
    n=name;
    absfn=0;
    if (n[0]=='/') absfn=1;
  } else {
    n=a_index[i]->name;
    absfn=a_index[i]->absolute;
  }

  f=fopen(n,"r");
  if (f) goto foip_ok;

  if (absfn) return 0;

  for(j=0;j<inc_count;j++) {
    strcpy(fname,inc_path[j]);
    strcat(fname,n);
    f=fopen(fname,"r");
    if (f)
      return(f);
  }

 foip_ok:
  return f;
}

void assemble_appends() {
  int i;

  for(i=0;i<a_count;i++) {
    fi=fopen_incpath(i,0);

    if (!fi) {
      strcpy(err_msg,"file not found: ");
      strcat(err_msg,a_index[i]->name);
      complain(SFATAL);
    }      

    assemble_file();
    fclose(fi);

  }
}

void param_sanity_test(int index) {
  struct Param *pp;
  pp=&par[index];

  if (pp->reg >= 0) {
    if ( (! pp->reference) && (pp->imm != 0) )
      canned_error(INVINDEX,SFATAL);

    if ( (pp->imm) != 0 )
      if ( (pp->reg != 13) && (pp->reg != 14) )
	canned_error(INVINDEX,SFATAL);

    if ( (pp->imm > 127) || (pp->imm < -128) )
      canned_error(CERANGE,SERROR);

    if (pp->reference)
      if (!((pp->reg==1)||((pp->reg>=10)&&(pp->reg<=15))))
	canned_error(SEMANTIC,SFATAL);

  }
}

void ensure_imm(int index) {
  struct Param *pp;
  pp=&par[index];

  if ((pp->reference)||(pp->cflag>=0)||(pp->reg>=0)||
      (pp->label)||(!pp->present))
    canned_error(MISNUMBER,SFATAL);
}

void range_check(i32b val,i32b min,i32b max) {
  if ((val<min)||(val>max))
    canned_error(CERANGE,SWARNING);
}

void resolve_references() {
  int i, lb;
  char dbcmd[72],*p;

  static char *sep=" \n\t\r";
  char ident[64];
  long values[3], ulb, placeholder;
  i32b v;

  fwrite("R1\n",1,3,todb);

  while(1) {
    fwrite("L1R\n",1,4,todb);
    if (!fgets(dbcmd,71,fromdb)) break;
    if (dbcmd[0]=='*') break;
    
    p=consume_ident(dbcmd);
    strcpy(ident,token);
    for(i=0;i<3;i++) {
      p=consume_whitespace(p);
      p=parse_number(p,&v);
      values[i]=v;
    }
    
    /* order 0=loc 1=offset 2=relative */

    if (fseek(fo,values[0]+hdr_size,SEEK_SET))
      goto internal_trouble;

    lb=get_label(ident,origin+values[0]);

    if (lb==-1) {
      strcpy(err_msg,"undefined label ");
      strcat(err_msg,ident);
      complain(SERROR);
      continue;
    }

    ulb=lb;
    if (ulb <0) ulb&=0xffff;

    /*
    fprintf(stderr,"REF %s $%x+$%x , rel=%d LA=$%x\n",ident,
	    values[0],values[1],
	    values[2],ulb);
    */

    if (values[2]) { /* relative */

      placeholder = ulb - (origin + values[0] + 1) + values[1];

      if ((placeholder<-128)||(placeholder>127)) {
	strcpy(err_msg,"relative reference out of range: ");
	strcat(err_msg,ident);
	complain(SERROR);
	continue;
      }

      /* fprintf(stderr,"rasm = $%x\n",placeholder); */
      asmout1(placeholder); --pc;
    } else { /* absolute */

      placeholder= ulb + values[1];

      if (placeholder > 0xffff) {
	strcpy(err_msg,"out of range: ");
	strcat(err_msg,ident);
	complain(SERROR);
	continue;
      }

      /* fprintf(stderr,"aasm = $%x\n",placeholder); */
      asmout_le_address(placeholder);
      pc-=2;
    }

  }

  return;

 internal_trouble:
  canned_error(KABOOM,SFATAL);
}

/* =====================================================================

                                   HEADER

   ===================================================================== */

void fill_header() {
  asmoutn(hdr_size,0);
  pc-=hdr_size;
  lock_header=1;
}

void basic_header() {
  fseek(fo,0,SEEK_SET);
  asmout1(0xfe);
  asmout_le_address(origin);
  asmout_le_address(origin+program_size-1);
  asmout_le_address(origin);
  pc-=7;

  if (origin<0x8000)
    canned_error(BORIGIN,SWARNING);
}

void uzix_header() {
  int i,a;

  fseek(fo,0,SEEK_SET);
  asmout1(0xc3);
  asmout_le_address(0x110);

  asmout1(0);

  i=get_label("etext",0x103); a = (i!=-1) ? i : 0;
  asmout_le_address(a);

  i=get_label("edata",0x103); a = (i!=-1) ? i : 0;
  asmout_le_address(a);

  i=get_label("ebss",0x103); a = (i!=-1) ? i : 0;
  asmout_le_address(a);

  asmoutn(4,0);

  i=get_label("__argc",0x103); a = (i!=-1) ? i : 0;
  asmout_le_address(a);
}

/* ====================================================================

                               DIRECTIVES

   ==================================================================== */

void read_filename(char *src, char *dest) {
  src=consume_whitespace(src);
  while( *src ) {
    if (*src<33)
      break;
    *(dest++)=*(src++);
  }
  *dest=0;
}

void parse_include(char *p) {
  char tmp[256];
  FILE *saved_fi;
  char saved_src[256];
  int saved_lnum;

  read_filename(p,tmp);
  
  if (!tmp[0])
    canned_error(FNEXPECT,SFATAL);

  if (!strcmp(tmp,src_file)) {
    canned_error(WCYCLIC,SWARNING);
    return;
  }

  saved_fi=fi;

  fi=fopen_incpath(0,tmp);
  if (!fi) {
    strcpy(err_msg,"file not found: ");
    strcat(err_msg,tmp);
    fclose(saved_fi);
    complain(SFATAL);
  }

  strcpy(saved_src,src_file);
  strcpy(src_file,tmp);
  saved_lnum=lnum;
  lnum=0;
  assemble_file();
  
  fclose(fi);
  fi=saved_fi;
  lnum=saved_lnum;
  strcpy(src_file,saved_src);
}

void parse_append(char *p) {
  char tmp[256];
  int i;

  read_filename(p,tmp);
  
  if (!tmp[0])
    canned_error(FNEXPECT,SFATAL);

  /* silently ignore duplicates */
  for(i=0;i<a_count;i++)
    if (!strcmp(tmp,a_index[i]->name))
      return;

  add_append(tmp);
}

void add_append(char *p) {
  struct AFile *n;
  int sz;

  sz=strlen(p);

  if (a_index_size >= a_count) {
    a_index_size += 4;

    if (a_index_size == 4)
      a_index=(struct AFile **)malloc(a_index_size * sizeof(struct AFile *));
    else
      a_index=(struct AFile **)realloc(a_index, a_index_size * sizeof(struct AFile *));
  }

  n=(struct AFile *)malloc(sizeof(struct AFile));  
  if (n) n->name=(char *)malloc(sz);

  if ( (!a_index) || (!n) || (!(n->name)) ) {
    econtext=1;
    canned_error(OOM,SFATAL);
  }

  strcpy(n->name,p);
  if (p[0] == '/') n->absolute=1; else n->absolute=0;
  a_index[a_count++]=n;
}

void parse_forget(char *p) {
  p=consume_whitespace(p);
  p=consume_ident(p);  
  label_forget_prefix(token,pc+origin-1);
}

void parse_repeat(char *p) {
  i32b rc;
  
  if (repeat.active)
    canned_error(NONEST,SFATAL);

  p=consume_whitespace(p);
  p=parse_number(p,&rc);
  repeat.count=(unsigned char)rc;

  if (repeat.count < 2)
    canned_error(RLOW,SFATAL);

  repeat.active=1;
  repeat.start=(unsigned long)ftell(fi);
  repeat.count--;
}

void parse_endr() {
  if (!repeat.active)
    canned_error(NOENDR,SFATAL);

  if (!repeat.count) {
    repeat.active=0;
    return;
  }

  if (fseek(fi,repeat.start,SEEK_SET)==-1)
    canned_error(KABOOM,SFATAL);

  repeat.count--;
}

void parse_header(char *p) {
  if (pc)
    canned_error(LATEHEADER,SFATAL);

  if (lock_header)
    canned_error(LOCKHEADER,SFATAL);
  
  p=consume_whitespace(p);
  p=consume_ident(p);
  
  if (!strcmp(token,"basic"))  {
    header_type=HDR_BASIC;
    hdr_size=7;
    fill_header();
    return;
  }
  if (!strcmp(token,"raw"))    {
    header_type=HDR_RAW;
    hdr_size=0;
    return;
  }
  if (!strcmp(token,"uzix")) {
    header_type=HDR_UZIX;
    hdr_size=16;
    fill_header();
    origin=0x110;	 
    return;
  }
  if (!strcmp(token,"msxdos")) {
    header_type=HDR_MSXDOS;
    hdr_size=0;
    origin=0x100;
    return;
  }
  
  strcpy(err_msg,"unknown header type");
  complain(SERROR);
}

void parse_origin(char *p) {
  int po;

  p=consume_whitespace(p);

  if (!(((*p>='0')&&(*p<='9'))||(*p=='$')||(*p=='#'))) {
    canned_error(MISSINGPAR,SERROR);
    return;
  }

  po=origin;
  p=parse_number(p,&origin);
  
  if (pc) {
    if ( (pc+po) > origin ) {
      canned_error(BACKORG,SERROR);
      return;
    } else {
      while( (pc+po) < origin )
	asmout1(0);
      origin = po;
    }
  } else {
    if (header_type==HDR_UZIX) {
      strcpy(err_msg,"origin readjusted with .header uzix");
      complain(SWARNING);
    }
    if (header_type==HDR_MSXDOS) {
      strcpy(err_msg,"origin readjusted with .header msxdos");
      complain(SWARNING);
    }
  }

  p=consume_whitespace(p);
  if (*p)
    canned_error(TRAILER,SWARNING);
}

int  get_macro(char *ident) {
  int i;
  for(i=0;i<m_count;i++)
    if (!strcmp(ident,m_index[i]->ident))
      return i;
  return -1;
}

void begin_record_macro(char *p) {
  char *q;
  struct Macro *m;

  if (macro_state != MACRO_OFF)
    canned_error(WRGSTUFF,SFATAL);

  q=consume_whitespace(p);
  q=consume_ident(q);

  if (get_macro(token) != -1) {
    strcpy(err_msg,"macro redeclared: ");
    strcat(err_msg,token);
    complain(SFATAL);
  }

  if (m_index_size >= m_count) {
    m_index_size += 32;
    if (m_index_size == 32)
      m_index=(struct Macro **)malloc(m_index_size * sizeof(struct Macro *));
    else
      m_index=(struct Macro **)realloc(m_index, m_index_size * sizeof(struct Macro *));
  }

  m=(struct Macro *)malloc(sizeof(struct Macro));

  if (m) m->mcode=(char *)malloc(1024);

  if ((!m)||(!m->mcode)||(!m_index)) {
    econtext=2;
    canned_error(OOM,SFATAL);
  }

  strcpy(m->ident,token);
  m->mcode[0]=0;
  m->sz=1;

  macro_state=MACRO_RECORDING;
  m_index[m_count++]=m;
}

void end_record_macro() {
  char *codep;

  if (macro_state != MACRO_RECORDING)
    canned_error(NOENDM,SFATAL);

  macro_state=MACRO_OFF;

  codep=m_index[m_count-1]->mcode;
  m_index[m_count-1]->mcode=(char *)realloc(codep,strlen(codep)+1);
  if (!m_index[m_count-1]->mcode) {
    econtext=3;
    canned_error(OOM,SFATAL);
  }
}

void expand_macro(char *p) {
  int i;
  char *q;
  
  if (macro_state != MACRO_OFF)
    canned_error(NONEST,SFATAL);
  
  q=consume_whitespace(p);
  q=consume_ident(q);

  for(i=0;i<m_count;i++)
    if (!strcmp(m_index[i]->ident,token)) {
      macrop=m_index[i]->mcode;
      macro_state=MACRO_EXPANDING;
      scope_b=pc+origin;
      scope_e=0;
      return;
    }
  
  strcpy(err_msg,"undefined macro: ");
  strcat(err_msg,token);
  complain(SFATAL);
}

void parse_empty(char *p) {
  char *q;
  i32b val;
  q=consume_whitespace(p);
  q=parse_number(q,&val);
  asmoutn(val,0);
}

void parse_ds(char *p) {
  char *q,c;
  char delim;

  q=consume_whitespace(p);
  
  switch(*q) {
  case '\'':
  case '\"': break;
  default:
    canned_error(MISSINGPAR,SFATAL);
  }

  delim=*(q++);

  for(;*q;q++) {
    if ((*q)==delim)
      break;
    if ((*q)=='\\') {
      ++q;
      c=escape_of(*q);
      asmout1(c);
      continue;
    } else
      asmout1(*q);
  }
}

void parse_db(char *p) {
  char *q;
  i32b val;

  q=consume_whitespace(p);

  while(*q) {
    q=parse_number(q,&val);
    q=consume_whitespace(q);    
    range_check(val,-128,255);
    asmout1(val);
  }
}

void parse_da(char *p) {
  p=consume_whitespace(p);
  p=consume_ident(p);

  if (token[0]==0)
    canned_error(BADLABEL,SFATAL);

  new_label_ref(token,pc,0,0);
  asmout2(0,0);
}

void parse_dw(char *p) {
  char *q;
  i32b val;

  q=consume_whitespace(p);

  while(*q) {
    q=parse_number(q,&val);
    q=consume_whitespace(q);    
    range_check(val,-32768,32767);
    asmout_le_address(val);
  }
}

void parse_def(char *p) {
  char *q,nlabel[65];
  i32b val;
  q=consume_whitespace(p);
  q=consume_ident(q);
  strcpy(nlabel,token);
  q=consume_whitespace(q);
  q=parse_number(q,&val);
  new_label(nlabel,val,scope_b,scope_e);
}

void do_align(char *p) {
  char *q;
  i32b val,ni,cz;
  q=consume_whitespace(p);
  q=parse_number(q,&val);

  if ((val==0)||(val==1)) {
    canned_error(CERANGE,SERROR);
    return;
  }

  ni = ((pc+origin-1)/val);
  ni = (ni+1) * val;

  cz=ni-pc-origin;

  asmoutn(cz,0);
}

/* =====================================================================

                                  PARSING

   ===================================================================== */

char * get_next_line(char *dest,int limit) {
  int i;
  char *p;

  switch(macro_state) {
  case MACRO_OFF:
  case MACRO_RECORDING:
    return(fgets(dest,limit,fi));
  case MACRO_EXPANDING:
    if (!macrop) {
      dest[0]=' '; dest[1]=0;
      scope_b=0; scope_e=0xffff;
      fix_label_scopes(pc+origin-1);
      macro_state=MACRO_OFF;
      return dest;
    }
    for(p=dest, i=0;(*macrop != 0) && (*macrop != '\n') && (i<limit);i++)
      *(p++) = *(macrop++);
    *p=0;
    if (*macrop == 0) macrop=0; else ++macrop;

    return(dest);    
  default:
    return 0;
  }
}

int clear_comments(char *s) {
  int label_hint=0;
  for(;*s;s++)
    switch(*s) {
    case ';':
    case '\n':
    case '\r':
      *s=0;
      goto cc_ret;
    case ':':
      label_hint=1;
      break;
    }
 cc_ret:
  return label_hint;
}

void parse_opcode() {
  char local[5];
  int i,j,a,b,h;

  j=strlen(token);

  if (j > 4)
    goto bad_opcode;

  strcpy(local,token);

  for(i=0;i<j;i++) {
    if ((local[i]>='0') && (local[i]<='9') )
      goto bad_opcode;
    if (local[i]=='_')
      goto bad_opcode;
    local[i]=myupper(local[i]);
  }

  strcpy(token,local);

  a=0; b=oc_count;
  opcode=-1;

  while(a!=b) {
    h=(a+b) >> 1;

    i=strcmp(local,oc_table[h]);
    if (!i) {
      opcode=h;
      return;
    }
    if (i<0) b=h; else a=h+1;
  }

 bad_opcode:
  strcpy(err_msg,"bad opcode ");
  strcat(err_msg,token);
  complain(SFATAL);
}

char *parse_param(char *p,int index) {
  struct Param *pp;
  char creg[3],c,oldcase[64];
  int sinal=0;

  pp=&par[index];
  creg[1]=creg[2]=0;

  pp->present=1;

  if (*p == '(') {
    pp->reference=1;
    ++p;
  }

  /* register */
  if (*p == '%') {
    creg[0]=myupper(*(++p));
    c=myupper(p[1]);
    if ( (c>='A') && (c<='Z') ) {
      creg[1]=c;
      ++p;
    }
    ++p;

    pp->reg=get_register(creg);

    if (pp->reg < 0) {
      strcpy(err_msg,"bad register ");
      strcat(err_msg,creg);
      complain(SFATAL);
    }
  }

  for(;*p;p++) {

    /* LABEL or CONDFLAG */
    c=myupper(*p);
    if ( ( (c >= 'A') && (c<='Z') ) || (c=='_') ) {
      p=consume_ident(p);      
      --p;
      strcpy(oldcase,token);

      pp->cflag=get_condflag(token);

      if (pp->cflag < 0) {
	pp->label=1;
	strcpy(pp->lb_name,oldcase);
      }
      
      continue;
    }

    switch(*p) {
    case ' ': case '\t':
      break;
    case ')':
      if (pp->reference) {
	return(++p);
      } else
	canned_error(WRGSTUFF,SFATAL);
      break;
    case '$': case '#': case '0': case '1':
    case '2': case '3': case '4': case '5':
    case '6': case '7': case '8': case '9':
    case '\'':
      p=parse_number(p,&(pp->imm));
      --p;
      if (sinal) { 
	pp->imm = -pp->imm;
	sinal=0;
      }
      break;
    case '+':
      sinal=0;
      break;
    case '-':
      sinal=1;
      break;
    case ',':
      return p;
    default:
      strcpy(err_msg,"unexpected character");
      complain(SFATAL);
    }
  }

  return p;
}

void reset_par() {
  int i;
  parcount=0;
  for(i=0;i<2;i++) {
    par[i].present=0;
    par[i].reference=0;
    par[i].reg=-1;
    par[i].imm=0;
    par[i].label=0;
    par[i].lb_name[0]=0;
    par[i].cflag=-1;
  }
}

char myupper(char c) {
  if ( (c>='a') && (c<='z') )
    return(c-32);
  else
    return c;
}

int  get_register(char *s) {
  int i;
  for (i=0;i<17;i++)
    if (!strcmp(regnames[i],s))
      return i;
  return -1;
}

int get_condflag(char *s) {
  int i,j;
  j=strlen(s);
  for(i=0;i<j;i++)
    s[i]=myupper(s[i]);
  for (i=0;i<8;i++)
    if (!strcmp(s,condflags[i]))
      return i;
  return -1;
}

/* ====================================================================

                                 OUTPUT

   ==================================================================== */

void asmout_le_address(int address) {
  unsigned char a[2];
  a[0]=(unsigned char)(address&0xff);
  a[1]=(unsigned char)((address>>8)&0xff);
  fwrite(a,1,2,fo);
  pc+=2;
}

void asmout1(unsigned char v) {
  fwrite(&v,1,1,fo);
  ++pc;
}

void asmout2(unsigned char v, unsigned char w) {
  unsigned char a[2];
  a[0]=v;
  a[1]=w;
  fwrite(a,1,2,fo);
  pc+=2;
}

void asmout4(unsigned char v, unsigned char w,
	     unsigned char x, unsigned char z)
{
  asmout2(v,w);
  asmout2(x,z);
}

void asmoutn(int count,unsigned char v) {
  char buffer[64];
  memset(buffer,v,64);
  pc+=count;
  while(count)
    count-=fwrite(buffer,1,(count>64)?64:count,fo);
}

/* =====================================================================

                           ERROR REPORTING

   ===================================================================== */

void resume_line() {
  fwrite("fa: ",1,4,stderr);
  write_int(stderr,err_count);
  fwrite(" errors",1,(err_count==1)?6:7,stderr);
  fwrite(", ",1,2,stderr);
  write_int(stderr,warn_count);
  fwrite(" warnings",1,(warn_count==1)?8:9,stderr);
  fwrite(newline,1,1,stderr);
}

void failure() {
  resume_line();
  close_fadb();
  if (fo) {
    fclose(fo); fo=0;
    unlink(ofile);
  }
  if (fi) {
    fclose(fi);
    fi=0;
  }
  exit(2);
}

void print_error(char *cn) {
  if (econtext) {
    fwrite("@context ",1,9,stderr);
    write_int(stderr,econtext);
    fwrite(newline,1,1,stderr);
  }

  fwrite("fa: ",1,4,stderr);
  fwrite(cn,1,strlen(cn),stderr);
  
  if (src_file[0]) {
    fwrite(" at ",1,4,stderr);
    fwrite(src_file,1,strlen(src_file),stderr);
    fwrite("(",1,1,stderr);
    write_int(stderr,lnum);
    fwrite("): ",1,3,stderr);
  } else {
    fwrite(": ",1,2,stderr);
  }
  fwrite(err_msg,1,strlen(err_msg),stderr);
  fwrite(newline,1,1,stderr);
  econtext=0;
}

void complain(int severity) {
  print_error(err_repo[severity]);
  if (severity==SWARNING) ++warn_count; else ++err_count;
  if (severity==SFATAL)   failure();
}

void canned_error(int can,int severity) {
  strcpy(err_msg,err_repo[can]);
  complain(severity);
}

/* ------------------------------------------------------------------- */
/* stuff to be dropped (or not) */

/* DEBUG only
   void dump_par() {
   printf("---dump---\n");
   printf("par0.present=%d\n",par[0].present);
   printf("par0.reg    =%d\n",par[0].reg);
   printf("par0.refer  =%d\n",par[0].reference);
   printf("par0.cflag  =%d\n",par[0].cflag);
   printf("par0.imm    =%d\n",par[0].imm);
   printf("par0.label  =%d\n",par[0].label);
   printf("par0.lb_name=%s\n",par[0].lb_name);

   printf("par1.present=%d\n",par[1].present);
   printf("par1.reg    =%d\n",par[1].reg);
   printf("par1.refer  =%d\n",par[1].reference);
   printf("par1.cflag  =%d\n",par[1].cflag);
   printf("par1.imm    =%d\n",par[1].imm);
   printf("par1.label  =%d\n",par[1].label);
   printf("par1.lb_name=%s\n",par[1].lb_name);
   }
*/
