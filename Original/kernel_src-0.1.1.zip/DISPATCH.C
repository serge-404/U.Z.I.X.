/**************************************************
UZI (Unix Z80 Implementation) Kernel:  dispatch.c
***************************************************/
#define NEED__DISPATCH
#define NEED__SCALL

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#endif
#include "unix.h"
#include "extern.h"

/* Dispatch table for system calls */

typedef	int (*DT)(void);

#define P(a)
#define	X(f)	((DT)(f))

GBL DT disp_tab[] = {
/*00*/	X(sys_access)	P((char *path, mode_t mode)),
	X(sys_alarm)	P((uint secs)),
	X(sys_brk)	P((char *addr)),
	X(sys_chdir)	P((char *dir)),
	X(sys_chmod)	P((char *path, mode_t mode)),
/*05*/	X(sys_chown)	P((char *path, int owner, int group)),
	X(sys_close)	P((int uindex)),
	X(sys_NONE)	P((void)),
	X(sys_dup)	P((int oldd)),
	X(sys_dup2)	P((int oldd, int newd)),
/*10*/	X(sys_execve)	P((char *name, char *argv[], char *envp[])),
	X(sys_exit)	P((int val)),
	X(sys_fork)	P((void)),
	X(sys_fstat)	P((int fd, char *buf)),
	X(sys_getfsys)	P((int dev, struct info_t *buf)),
/*15*/	X(sys_getgid)	P((void)),
	X(sys_getpid)	P((void)),
	X(sys_getppid)	P((void)),
	X(sys_getuid)	P((void)),
	X(sys_ioctl)	P((int fd, int request, void *data)),
/*20*/	X(sys_kill)	P((int pid, int sig)),
	X(sys_link)	P((char *oldname, char *newname)),
	X(sys_mknod)	P((char *name, mode_t mode, int dev)),
	X(sys_mount)	P((char *spec, char *dir, int rwflag)),
	X(sys_open)	P((char *name, int flag)),
/*25*/	X(sys_pause)	P((void)),
	X(sys_pipe)	P((int fildes[2])),
	X(sys_read)	P((int d, char *buf, uint nbytes)),
	X(sys_sbrk)	P((uint incr)),
	X(sys_lseek)	P((int file, off_t offset, int whence)),
/*30*/	X(sys_setgid)	P((int gid)),
	X(sys_setuid)	P((int uid)),
	X(sys_signal)	P((int sig, int (*func)())),
	X(sys_stat)	P((char *path, char *buf)),
	X(sys_stime)	P((time_t *tvec)),
/*35*/	X(sys_sync)	P((void)),
	X(sys_time)	P((time_t *tvec)),
	X(sys_times)	P((struct tms *buf)),
	X(sys_umask)	P((int mask)),
	X(sys_umount)	P((char *spec)),
/*40*/	X(sys_unlink)	P((char *path)),
	X(sys_utime)	P((char *path, struct utimbuf *)),
	X(sys_wait)	P((int *statloc)),
	X(sys_write)	P((int d, char *buf, uint nbytes)),
	X(sys_reboot)	P((char p1, char p2)),
/*45*/	X(sys_symlink)	P((char *oldname, char *newname)),
	X(sys_trace)	P((int onoff)),
	X(sys_chroot)	P((char *path)),
};

GBL uchar dtsize = sizeof(disp_tab)/sizeof(disp_tab[0]);

#if DEBUG > 1
GBL char *disp_names[] = {
/*00*/	"access",
	"alarm",
	"brk",
	"chdir",
	"chmod",
/*05*/	"chown",
	"close",
	"NONE",
	"dup",
	"dup2",
/*10*/	"execve",
	"exit",
	"fork",
	"fstat",
	"getfsys",
/*15*/	"getgid",
	"getpid",
	"getppid",
	"getuid",
	"ioctl",
/*20*/	"kill",
	"link",
	"mknod",
	"mount",
	"open",
/*25*/	"pause",
	"pipe",
	"read",
	"sbrk",
	"seek",
/*30*/	"setgid",
	"setuid",
	"signal",
	"stat",
	"stime",
/*35*/	"sync",
	"time",
	"times",
	"umask",
	"umount",
/*40*/	"unlink",
	"utime",
	"wait",
	"write",
	"reboot",
/*45*/	"symlink",
	"systrace",
	"chroot",
};
#endif

