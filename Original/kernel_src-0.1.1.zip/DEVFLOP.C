/*******************************************************
UZIX (Unix Z80 Implementation for MSX) Kernel:  devflop.c

Floppy disk drivers (real FD and file mapped)
NEED:	devflop.mtc (devflop.msx)

*******************************************************/
#define NEED__DEVFLOP
#define NEED__MACHDEP

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#include "sys\ioctl.h"
#endif
#include "unix.h"
#include "extern.h"

/* If __ONFILE defined then floppies will be simulated on files
 * __ONFILE"minor"
 * This option mainly for MS DOS!
 */
#ifdef PC_HOSTED
#define __ONFILE	"..\\floppy"	/**/
#endif

#ifdef Z80MU
/* name must be in FCB form, without point and in capital letters */
#define	__ONFILE	"FLOP"
#endif

/* Floppy disk sector size */
#define SEC_SIZE	512

/* DEVICE DRIVER - floppy disks */

#ifdef __ONFILE
STATIC int files[2] = {0, 0};
#else /* __ONFILE */
#ifdef MSX_HOSTED
typedef uchar fdinfo_t;

STATIC fdinfo_t fdinfo[2] = {
	0xF9,
	0xF9,
};

STATIC uchar fmediaid;

#else /* MSX_HOSTED */
typedef struct {
	uint	tracks;
	uchar	heads;
	uchar	sectors;
} fdinfo_t;

STATIC uchar fhead, fsector;
STATIC uint ftrack;

/* in this table we keep current floppy disks configuration */
STATIC fdinfo_t fdinfo[2] = {
	{ 80, 2, 9 },		/* 720 K */
	{ 80, 2, 9 }		/* 720 K */
};
#endif /* MSX_HOSTED */
#endif /* __ONFILE */

STATIC uchar fdrive;
STATIC uint firstblk, nbytes, nblocks;
STATIC int ferror;
STATIC uchar *fbuf;

STATIC int fd __P((uchar rdflag, uchar minor, uchar rawflag));
STATIC int dskread __P((void));
STATIC int dskwrite __P((void));
#ifdef __ONFILE
STATIC int dskclose __P((void));
STATIC int openonfile __P((char *, int));
#else
STATIC void reset __P((void));
#endif

#ifdef PC_HOSTED
#include "devflop.mtc"
#else	/* PC_HOSTED */
#ifdef MSX_HOSTED
/* MSX machine */
#include "devflop.msx"
#else /* MSX_HOSTED */
/* other kind of low-level access */
#endif /* MSX_HOSTED */
#endif	/* PC_HOSTED */

/* common routine for read/write floppys */
STATIC int fd(rdflag, minor, rawflag)
	uchar rdflag;		/* 1 if read, 0 if write */
	uchar minor;		/* floppy number */
	uchar rawflag;		/* 0 - buffered, 1 - raw, 2 - swapfile */
{
#ifndef __ONFILE
#ifndef MSX_HOSTED
	fdinfo_t *fi = fdinfo+minor;
#endif /* MSX_HOSTED */
	uchar retry = 3;
#endif /* __ONFILE */

	minor &= 1;		/* ??? */
	if (rawflag) {
		fbuf = udata.u_base;
		nbytes = udata.u_count;
		firstblk = (uint)(udata.u_offset >> BUFSIZELOG);
	}
	else {
		fbuf = udata.u_buf->bf_data;
		nbytes = BUFSIZE;
		firstblk = udata.u_buf->bf_blk;
	}
#if BUFSIZELOG > 8
	nblocks = (uchar)((nbytes + (BUFSIZE - 1)) >> 8) >> (BUFSIZELOG-8);
#else
	nblocks = (nbytes + (BUFSIZE - 1)) >> BUFSIZELOG;
#endif
#ifdef __ONFILE
	fdrive = files[minor];
	if ((ferror = rdflag ? dskread() : dskwrite()) != 0) {
		kprintf("fd_%s: error %x at blk %d (total %d)\n",
		    rdflag ? "read":"write", ferror & 0xFF,
		    firstblk, nblocks);
		panic("stop");
	}
#else /* __ONFILE */
#ifdef MSX_HOSTED
	fdrive = minor;
	fmediaid = fdinfo[(uint)minor];
	for (;;) {
		if ((ferror = rdflag ? dskread() : dskwrite()) != 0) {
			if (retry-- == 0)
				break;
			reset();
			continue;
		}
		if (--nblocks == 0)
			break;
		fbuf += SEC_SIZE;
	}
	if (ferror) {
		if ((rdflag == 0) && (ferror == 1)) { /* write-protect error */
			kprintf("fd_write: write-protect error\n");
			return 1;
		}
		kprintf("fd_%s: error %x at sector %d (id %x)\n",
		    rdflag ? "read":"write", ferror & 0xFF,
		    firstblk, fmediaid);
		panic("stop");
	}
#else /* MSX_HOSTED */
	fdrive = minor;
	ftrack = firstblk / (fi->sectors*fi->heads);
	firstblk %= (fi->sectors*fi->heads);
	fhead = firstblk / fi->sectors;
	fsector = firstblk % fi->sectors + 1;
	for (;;) {
		if ((ferror = rdflag ? dskread() : dskwrite()) != 0) {
			if (retry-- == 0)
				break;
			reset();
			continue;
		}
		if (--nblocks == 0)
			break;
		if (++fsector > fi->sectors) {
			fsector = 1;
			if (++fhead >= fi->heads) {
				fhead = 0;
				++ftrack;
			}
		}
		fbuf += SEC_SIZE;
	}
	if (ferror) {
		kprintf("fd_%s: error %x at HCS %d/%d/%d\n",
		    rdflag ? "read":"write", ferror & 0xFF,
		    fhead, ftrack, fsector);
		panic("stop");
	}
#endif /* MSX_HOSTED */
#endif /* __ONFILE */
	return 0;
}

/* open device - checks for floppy geometry */
GBL int fd_open(minor)
	uchar minor;
{
#ifdef __ONFILE
	char name[80], *p = __ONFILE;
	int i;

	for (i = 0; p[i]; ++i)
		name[i] = p[i];
	name[i++] = minor+'0';
	name[i] = 0;

	return openonfile(name, minor);
#else /* __ONFILE */
#ifdef MSX_HOSTED
	uchar retr = 3;

	fdrive = (uchar)minor;
	fmediaid = 0xF9;
	fbuf = (uchar *)TEMPDBUF;
	firstblk = 0;
	while (--retr != 0) {
		reset();
		if (dskread() == 0) {
			fdinfo[minor] = ((uchar *)TEMPDBUF)[0x15];
			return 0;
		}
	}
	return -1;
#else /* MSX_HOSTED */
	static fdinfo_t tfi[] = {
		{ 80, 2, 18 },
		{ 80, 2, 15 },
		{ 80, 2, 9 },
		{ 40, 2, 9 },
	};
	uchar buf[SEC_SIZE];	/* ??? stack too deep! */
	fdinfo_t *fi = tfi;

	fdrive = (uchar)minor;
	fbuf = buf;
	while (fi < tfi+sizeof(tfi)/sizeof(fdinfo_t)) {
		uchar retr = 3;

		fhead = fi->heads-1;
		fsector = fi->sectors;
		ftrack = fi->tracks-40;
		while (--retr != 0) {
			reset();
			if (dskread() == 0) {
				bcopy(fi,fdinfo+minor,sizeof(fdinfo_t));
				return 0;
			}
		}
		++fi;
	}
	return -1;
#endif /* MSX_HOSTED */
#endif /* __ONFILE */
}

/* close device - do nothing now */
GBL int fd_close(minor)
	uchar minor;
{
	NOTUSED(minor);
#ifdef __ONFILE
	if (dskclose())
		return -1;
#endif /* __ONFILE */
	return 0;
}

/* read data from device */
GBL int fd_read(minor, rawflag)
	uchar minor;
	uchar rawflag;
{
	return fd(1, (uchar)minor, (uchar)rawflag);
}

/* write data to device */
GBL int fd_write(minor, rawflag)
	uchar minor;
	uchar rawflag;
{
	return fd(0, (uchar)minor, (uchar)rawflag);
}

#if 0
/* do ioctl on device - return error now */
GBL int fd_ioctl(minor, req, ptr)
	uchar minor;
	int req;
	void *ptr;
{
	NOTUSED(req);
	NOTUSED(ptr);
	fdrive = minor;
	return (-1);
}

/* init device */
GBL int fd_init(minor)
	uchar minor;
{
	fdrive = minor;
	return 0;
}
#endif
