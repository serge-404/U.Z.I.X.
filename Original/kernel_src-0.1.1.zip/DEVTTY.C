/**************************************************
UZI (Unix Z80 Implementation) Kernel:  devtty.c
***************************************************/
#define NEED__DEVTTY
#define NEED__DEVIO
#define NEED__MACHDEP
#define NEED__PROCESS
#define NEED__SCALL

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#include "errno.h"
#include "sys\ioctl.h"
#endif
#include "unix.h"
#include "extern.h"

/* DEVICE DRIVER - tty */

#ifndef TABSIZE
#define	TABSIZE	8
#endif

#ifndef TTYSIZ
#define TTYSIZ 80
#endif

#ifndef EOFKEY
#define EOFKEY	('Z' & 037)
#endif

uint _getc __P((void));
void _putc __P((uchar));

STATIC uchar ttyinbuf[TTYSIZ];	/* terminal lookahead buffer */
STATIC uchar rawmode;

#ifdef __KERNEL__
STATIC queue_t ttyinq = {	/* terminal lookahead queue descriptor */
	ttyinbuf,
	ttyinbuf,
	ttyinbuf,
	TTYSIZ,
	0,
	TTYSIZ/2
};

STATIC uchar suspendflag;	/* Flag for ^S/^Q */
STATIC uchar flshflag;		/* Flag for ^O */
#else /* __KERNEL__ */
uchar _xbdos __P((uint, uchar));
#endif /* __KERNEL__ */

#ifdef PC_HOSTED
#include "devtty.mtc"
#else
#ifdef MSX_HOSTED
#include "devtty.msx"
#else
#endif
#endif

#ifndef __KERNEL__
#ifdef _MSX_DOS
#ifdef Z80MU
#define BDOSADDR	0FEFEh
#else
#define BDOSADDR	00005h
#endif

uchar _xbdos(uint de, uchar c) { /* avoid conflict with UTILDOS xxbdos */
	asm("	push bc");
	asm("	call " __str1(BDOSADDR));
	asm("	ld l,a");
	asm("	pop bc");
}

#else	/* _MSX_DOS */
extern int bdos(int, uint, uint);

uchar _xbdos(de, c)
	uint de;
	uchar c;
{
	return bdos(c, de, 0);
}
#endif	/* _MSX_DOS */
#endif	/* __KERNEL__ */

/* read from device */
GBL int tty_read(minor, rawflag)
	uchar minor;
	uchar rawflag;
{
#ifdef __KERNEL__
	uchar ch;
	count_t nread = 0;

	NOTUSED(minor);
	NOTUSED(rawflag);
	/* we need no more then u_count chars */
	while (nread < udata.u_count) {
		for (;;) {
			_di();
			if (remq(&ttyinq, &ch))
				break;	/* there are char in input queue */
			_ei();
			psleep(&ttyinq); /* wait for char */
			if (udata.u_ptab->p_intr) {	/* messy */
				udata.u_error = EINTR;
				return (-1);	/* interrupted by signal */
			}
		}
		_ei();
		if (nread++ == 0 && ch == EOFKEY)
			return 0;		/* EOF */
		*udata.u_base++ = ch;
		if (!rawmode && ch == '\n')
			break;			/* LF teminates input */
	}
	return nread;
#else /* __KERNEL__ */
	int nread;

	NOTUSED(minor);
	NOTUSED(rawflag);
	ttyinbuf[0] = udata.u_count < sizeof(ttyinbuf)-2 ?
				udata.u_count : sizeof(ttyinbuf)-2;
	ttyinbuf[1] = 0;
	_xbdos((uint)ttyinbuf, 10);	/* Read console buffer */
	_xbdos('\n', 2);

	nread = ttyinbuf[1];
	ttyinbuf[nread + 2] = '\n';
	bcopy(ttyinbuf + 2, udata.u_base, nread + 1);
	return (ttyinbuf[2] == EOFKEY ? -1 : nread + 1);
#endif /* __KERNEL__ */
}

/* write data to device */
GBL int tty_write(minor, rawflag)
	uchar minor;
	uchar rawflag;
{
#ifdef __KERNEL__
	uchar ch;
	count_t towrite = udata.u_count;

	NOTUSED(minor);
	NOTUSED(rawflag);
	while (towrite != 0) {
		--towrite;
		for (;;) {	/* Wait on the ^S/^Q flag */
			_di();
			if (!suspendflag)
				break;
			/* wait for ^Q/^O or signal */
			psleep(&suspendflag);
			if (udata.u_ptab->p_intr) {
				udata.u_error = EINTR;
				return (-1);	/* interrupted by signal */
			}
		}
		_ei();
		/* Attemption to remove ch
		 * (putc(udata.u_base); ++udata.u_base) lead to
		 * illegal code generated (access through I/O space)
		 */
		ch = *udata.u_base++;
		if (!flshflag) _putc(ch);
	}
	return udata.u_count;
#else /* __KERNEL */
	uint count = udata.u_count;

	NOTUSED(minor);
	NOTUSED(rawflag);
	while (udata.u_count-- != 0) {
		if (*udata.u_base == '\n')
			_xbdos('\r', 2);
		_xbdos((uint)*udata.u_base, 2);
		udata.u_base = udata.u_base+1;
	}
	return count;
#endif /* __KERNEL */
}

/* do ioctl on device */
GBL int tty_ioctl(minor, req, ptr)
	uchar minor;
	int req;
	void *ptr;
{
	uchar ret = rawmode;

	NOTUSED(minor);
	NOTUSED(ptr);
	if ((uchar)req == TTY_RAW)		rawmode = 1;
	else if ((uchar)req == TTY_COOKED)	rawmode = 0;
	else	return -1;
	return ret;
}

#if 0
/* open device */
GBL int tty_open(minor)
	uchar minor;
{
	NOTUSED(minor);
	return 0;
}

/* close device */
GBL int tty_close(minor)
	uchar minor;
{
	NOTUSED(minor);
	return 0;
}

/* init device */
GBL int tty_init(minor)
	uchar minor;
{
	NOTUSED(minor);
	return 0;
}
#endif

#ifdef __KERNEL__
/* This tty polling routine checks to see if the keyboard data arrived.
 * If so it adds the character to the tty input queue, echoing and
 * processing backspace and carriage return.  If the queue contains a full
 * line, it wakes up anything waiting on it.  If it is totally full, it
 * beeps at the user.
 */
GBL int tty_poll(VOID) {
	uchar oc;
	register uint c;
	register int found = 0;
	char i;

again:	if ((c = _getc()) == 0)
		return found;
	oc = c;
	if (oc == 127) oc='\b';		/* treat DELETE as BS */
	if (rawmode) {
		insq(&ttyinq, oc);
		goto Wake;
	}
	if (oc == ('O' & 037)) {	/* ^O */
		flshflag = !flshflag;
		oc = ('Q' & 037);	/* remove suspend flag if any */
	}
	if (oc == ('C' & 037)) {	/* ^C */
		_putc('^');
		_putc('C');
		_putc('\n');
		sendsig(NULL, SIGINT);
	}
	else if (oc == ('S' & 037))	/* ^S */
		suspendflag = 1;
	else if (oc == ('Q' & 037)) {	/* ^Q */
		suspendflag = 0;
		wakeup(&suspendflag);
	}
	else if (oc == '\b') {		/* backspace */
		if (uninsq(&ttyinq, &oc)) {
			if (oc == '\n')
				insq(&ttyinq, oc); /* Don't erase past newline */
			else if (oc == '\t') {		
				for (i = TABSIZE; i > 0; i--) {/* what else we need? */
					_putc('\b');
					_putc(' ');	/* just erasing 8 */
					_putc('\b');	/* chars is buggy */
				}
			}
			else {
				_putc('\b');
				_putc(' ');
				_putc('\b');
			}
		}
	}
#ifdef PC_HOSTED
	else if (oc == 0 && (c & 0xFF00))
		;		/* don't accept extended ASCII ??? */
#endif
	else {
		if (oc == '\r') 	/* treat CR as LF */
			oc = '\n';
		if (insq(&ttyinq, oc)) {
			if (oc >= ' ' || oc == '\n' || oc == '\t')
				_putc(oc);	/* echo char */
		}
		else	_putc('\007');	/* Beep if no more room */
	}
	if (oc == '\n' || oc == EOFKEY) /* EOL or EOF */
Wake:		wakeup(&ttyinq);
	++found;
	goto again;		/* Loop until the uart has no data ready */
}
#endif

