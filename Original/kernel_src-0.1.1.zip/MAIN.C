/**************************************************
UZI (Unix Z80 Implementation) Kernel:  data.c
***************************************************/
#define __MAIN__COMPILATION
#define NEED__MACHDEP
#define NEED__SCALL

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#endif
#include "unix.h"
#include "extern.h"

/* Main procedure and uzix datas */

void main(VOID) {
#if 0				/* Console basic test */
	uchar a;

	kprintf("\nTesting console I/O.\nHit any key. ESCAPE ends. CTRL+Z for debug.\n\n");
	for (;;) {
		while ((a = _getc()) == 0)
			;
		if (a == 27)
			break;
		_putc(a);
	}
#endif
#if 1
	kprintf("Welcome to UZIX " VERSION "." RELEASE "\n");
#else
	kprintf("Welcome to UZIX %s.%s\n", VERSION, RELEASE);
#endif
	arch_init();		/* NORETURN */
}
