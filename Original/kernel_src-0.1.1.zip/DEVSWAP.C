/**************************************************
UZI (Unix Z80 Implementation) Kernel:  devflop.c
***************************************************/
#define NEED__DEVSWAP
#define NEED__MACHDEP

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#include "sys\ioctl.h"
#endif
#include "unix.h"
#include "extern.h"

/* SWAPPER - NOT A DEVICE DRIVER! */

#ifdef PC_HOSTED
#include "devswap.mtc"
#else /* PC_HOSTED */
#ifdef MSX_HOSTED
#include "devswap.msx"
#else /* MSX_HOSTED */
#endif /* MSX_HOSTED */
#endif /* PC_HOSTED */
