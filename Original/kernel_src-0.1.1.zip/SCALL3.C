/**************************************************
UZI (Unix Z80 Implementation) Kernel:  scall3.c
***************************************************/
#define NEED__DEVIO
#define NEED__FILESYS
#define NEED__MACHDEP
#define NEED__SCALL

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#include "errno.h"
#include "sys\stat.h"
#endif
#include "unix.h"
#include "extern.h"

/* Implementation of system calls */

#define ISIZE(ino)	((ino)->c_node.i_size)

/* shortcuts for 'udata' access */
#define UWHERE		(udata.u_offset)
#define UBLK		(UWHERE.o_blkno)
#define UOFF		(UWHERE.o_offset)
#define UBAS		(udata.u_base)
#define UCNT		(udata.u_count)
#define UERR		(udata.u_error)

#ifdef __KERNEL__

LCL int repack __P((char **argp, char **envp));
LCL void *scop __P((register char **argv, uchar cnt, char *to, char *real));
LCL uint ssiz __P((register char **argv, uchar *cnt, char **smin));
LCL void exec2 __P((void));

STATIC uint __argc;
STATIC char **__argv;
STATIC char **__envp;

/* check for arguments size */
LCL uint ssiz(argv, cnt, smin)
	register char **argv;
	uchar *cnt;
	char **smin;
{
	char *p, *mi = *smin;
	uint n = 0;

	*cnt = 1;
	while ((p = *argv++) != NULL) {
		if (p < mi)	mi = p;
		while (++n, *p++ != '\0')
			;
		++(*cnt);
	}
	*smin = mi;
	return n;
}

/* copy arguments vector */
LCL void *scop(argv, cnt, to, real)
	register char **argv;
	uchar cnt;
	char *to, *real;
{
	char *s, **a = (char **)to, *q = to + sizeof(char *) * cnt;

	while ((s = *argv++) != NULL) {
		*a++ = real;
		while (++real, (*q++ = *s++) != '\0')
			;
	}
	*a = NULL;
	return q;
}

/* move all arguments to top of program memory */
/* stack can't be near top of program memory */
/* PROGBASE area is used as draft area */
LCL int repack(argp, envp)
	char **argp;
	char **envp;
{
	uint tot, et, asiz, esiz;
	uchar acnt, ecnt;
	register char *p = (void *)PROGBASE;
	char *amin = (void *)UZIXBASE;

	asiz = ssiz(argp, &acnt, &amin);
	esiz = ssiz(envp, &ecnt, &amin);
	
	tot = (asiz + sizeof(char *) * acnt) +
	      (et = esiz + sizeof(char *) * ecnt);
	if ((uint)p + tot > (uint)amin) 	/* p == PROGBASE! */
		return 1;	/* no room for args */
	p = scop(argp, acnt, p, (char *)(UZIXBASE - 1 - et - asiz));
	scop(envp, ecnt, p, (char *)(UZIXBASE - 1 - esiz));
	__envp = (char **)(UZIXBASE - 1 - et);
	__argv = (char **)(UZIXBASE - 1 - tot);
	__argc = acnt-1;
	bcopy((void *)PROGBASE, __argv, tot);
	return 0;
}

/* exec2() second step of execve - executed on system stack! */
LCL void exec2(VOID) {
	register char **p, *progptr;
	register blkno_t pblk;
	uchar blk = 0;
	char *buf;

	/* Read in the rest of the program */
	progptr = (char *)PROGBASE;
	while (blk <= UCNT) {
		if ((pblk = bmap(udata.u_ino, blk, 1)) != NULLBLK) {
			buf = bread(udata.u_ino->c_dev, pblk, 0);
			bcopy(buf, progptr, BUFSIZE);
			brelse((bufptr)buf);
		}
		progptr += BUFSIZE;
		++blk;
	}
	i_deref(udata.u_ino);
	/* Zero out the free memory */
	bzero(progptr, (uint) ((char *)__argv - progptr));
	udata.u_ptab->p_break = progptr;
	/*udata.u_break = progptr;*/
	/* PROGPTR is below E_BSS! Must be equal or above else program
	data can be overwritten by malloc()! */
	udata.u_break = (*(uint *)E_BSS);
	udata.u_traceme = 0;
	/* Fill in udata.u_name */
	bcopy(*__argv, udata.u_name, DIRNAMELEN);
	/* Shove argc and the address of argv just below argv */
	p = __argv;
	*--__argv = (char *) __envp;
	*--__argv = (char *) p;
	*--__argv = (char *) __argc;
	/* Machine dependant jump into the program, first setting the stack */
	doexec((uint)__argv);	/* NORETURN */
}

/*********************************************************
 SYSCALL execve(char *name, char *argv[], char *envp[]);
*********************************************************/
#define name (char *)udata.u_argn1
#define argv (char **)udata.u_argn2
#define envp (char **)udata.u_argn3
GBL int sys_execve(VOID) {
	register inoptr ino;
	register uchar *buf;
	register sig_t *sp;
	uchar magic, magic1, magic2;
	uint mblk;

	if ((ino = namei(name, NULL, 1)) == 0)
		goto Err1;
	mblk = (uint)ISIZE(ino);	/* image length in bytes */
	if (PROGBASE + ISIZE(ino) >= UZIXBASE) { /*!!! long operation */
		UERR = ENOMEM;
		goto Ret;
	}
	if ((getperm(ino) & S_IOEXEC) == 0 ||
	      getmode(ino) != S_IFREG ||
	      (ino->c_node.i_mode & (S_IEXEC | S_IGEXEC | S_IOEXEC)) == 0) {
		UERR = EACCES;
		goto Ret;
	}
	/* save information about program size in blocks/top */
	UCNT = (mblk + BUFSIZE - 1) >> BUFSIZELOG;
	UBAS = (void *)(PROGBASE + mblk + 1024); /* min +1K stack */
	/* Read in the first block of the new program */
	buf = bread(ino->c_dev, bmap(ino, 0, 1), 0);
	magic = ((exeptr)buf)->e_magic;
	magic1 = ((uchar *)buf)[0];
	magic2 = ((uchar *)buf)[1];
	brelse((bufptr)buf);
	if (magic != EMAGIC) {
		if (magic1 == '#' && magic2 == '!')
			UERR = ESHELL;
		else	UERR = ENOEXEC;
		goto Ret;
	}
/*	setftim(ino, A_TIME);	/* ??? */
	/* Turn off caught signals */
	sp = udata.u_sigvec;
	while (sp < (udata.u_sigvec + NSIGS)) {
		if ((sig_t)(*sp) != SIG_IGN)
			*(sig_t *)sp = SIG_DFL;
		++sp;
	}
	/* Here, check the setuid stuff. No other changes need be
	 * made in the user data
	 */
	if (ino->c_node.i_mode & S_ISUID) udata.u_euid = ino->c_node.i_uid;
	if (ino->c_node.i_mode & S_ISGID) udata.u_egid = ino->c_node.i_gid;
	/* At this point, we are committed to reading in and executing
	 * the program. We switch to a local stack, and pass to it the
	 * necessary parameter: ino
	 */
	udata.u_ino = ino;	/* Temporarly stash these here */
	tempstack();
	if (repack(argv, envp))
		goto Ret;
	/*??? at this point all local variables is destroyed! */
	if (UBAS > (void *)__argv) {
		UERR = E2BIG;
		ino = udata.u_ino;
		goto Ret;
	}
	exec2();

Ret:	i_deref(ino);
Err1:	return (-1);
}
#undef name
#undef argv
#undef envp
#endif	/* __KERNEL__ */

