/*
 */
#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#include "errno.h"
#include "fcntl.h"
#include "sys\stat.h"
#include "sys\seek.h"
#include "sys\ioctl.h"
#endif
#include "unix.h"
#include "extern.h"

#ifdef USETEST
/* May be used for testing syscalls */
GBL void tester(where) 
	int where;
{
	if (where == 1)
		idump();
/*	else	traceon = 1;	/**/
}
#endif

