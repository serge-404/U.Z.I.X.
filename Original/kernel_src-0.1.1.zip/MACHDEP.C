/**************************************************
UZI (Unix Z80 Implementation) Kernel:  machdep.c
***************************************************/
#define NEED__DEVTTY
#define NEED__DEVIO
#define NEED__MACHDEP
#define NEED__PROCESS
#define NEED__DISPATCH
#define NEED__SCALL

#include "uzix.h"
#ifdef SEPH
#include "types.h"
#include "signal.h"
#include "errno.h"
#endif
#include "unix.h"
#include "extern.h"

/* Additional machine dependent subroutines for kernel */
#ifdef __KERNEL__
long unix __P((uint callno, ... /*uint arg1, uint arg2, uint arg3, uint arg4*/));
LCL long unixret __P((void));
#endif /* __KERNEL__ */

#ifdef PC_HOSTED
#include "machdep.mtc"
#else
#ifdef MSX_HOSTED
#include "machdep.msx"
#else
#endif
#endif

/* Architecture specific init.
 * This is called at the very beginning to initialize everything.
 * It is the equivalent of main()
 */
GBL void arch_init(VOID) {
#ifdef __KERNEL__
	_di();
	tempstack();
	initsys();	/* Initialize system dependent parts */
/*	inint = 0;	/* not in interrupt */
	TICKSPERMIN = TICKSPERSEC * 60;
	MAXTICKS = TICKSPERSEC / 2;
	_ei();
	ARCH_INIT;	/* MACRO */
	init(); 	/* NORETURN */
#else /* __KERNEL__ */
	inint = 0;
	udata.u_euid = 0;
	udata.u_insys = 1;
	udata.u_mask = 022;
#endif /* __KERNEL__ */
}

/* Valaddr() checks to see if a user-supplied address is legitimate
 */
GBL int valadr(base, size)
	void *base;
	uint size;
{
#ifdef __KERNEL__
	if (/* (uint)base < PROGBASE || */
	    (uint)base + size < (uint)base ||
	    (uint)base + size >= UZIXBASE) {	/* ??? kernel data problem */
		udata.u_error = EFAULT;
		return 0;
	}
#else
	NOTUSED(base);
	NOTUSED(size);
#endif /* __KERNEL__ */
	return 1;
}

/* This adds two tick counts together.
 * The t_time field holds up to sixty second of ticks,
 * while the t_date field counts minutes
 */
GBL void addtick(t1, t2)
	register time_t *t1, *t2;
{
	t1->t_time += t2->t_time;
	t1->t_date += t2->t_date;
	while (t1->t_time >= TICKSPERMIN) {
		t1->t_time -= TICKSPERMIN;
		++t1->t_date;
	}
}

/* add one tick to time
 * The t_time field holds up to sixty second of ticks,
 * while the t_date field counts minutes
 */
GBL void incrtick(t)
	register time_t *t;
{
	while (++t->t_time >= TICKSPERMIN) {
		t->t_time -= TICKSPERMIN;
		++t->t_date;
	}
}

GBL void sttime(tvec)
	int *tvec;
{
	NOTUSED(tvec);
	panic("Calling sttime");	/* ??? */
}

GBL void rdtime(tloc)
	register time_t *tloc;
{
#ifndef __KERNEL__
	rdtod();
#endif /* __KERNEL__ */
	_di();
	*tloc = tod;
	_ei();
}

/* Panic() prints an error message and dies */
GBL void panic(s, a1, a2, a3)
	char *s;
	int a1, a2, a3;
{
	_di();
	++inint;
	kprintf("\nPANIC: ");
	kprintf(s,a1,a2,a3);
	kprintf("\n");
#if 0
	idump();
#endif
	_abort(99);
}

/* warning() prints warning message to console */
GBL void warning(s, a1, a2, a3)
	char *s;
	int a1, a2, a3;
{
	kprintf("WARNING: ");
	kprintf(s,a1,a2,a3);
	kprintf("\n");
}

/* kputs() prints zero-terminated character string to console */
GBL void kputs(s)
	register char *s;
{
	while (*s)
		kputchar((uchar)*(s++));
}

#if 0
/* PUTC handles /n, kputchar now is a #define kputchar _putc */
/* kputchar() prints one char to console
 */
GBL void kputchar(c)
	uchar c;
{
#ifdef HTC
	if (c != '\n')
		_putc(c);
	else {
		_putc('\r');
		_putc('\n');
	}
#else
	if (c == '\n')
		_putc('\r');
	_putc(c);
#endif
}
#endif

#if DEBUG > 0
/* _idump() dumps state of all inodes
 */
STATIC void _idump(VOID) {
	register inoptr ip = i_tab;

	kprintf("Inodes:\tMAGIC\tDEV\tNUM\tMODE\tNLINK\t(DEV)\tREFS\tDIRTY\n");
	while (ip < i_tab + ITABSIZE) {
		kprintf("#%d\t%d\t%p\t%u\t%06o\t%d\t%p\t%d\t%d\n",
			ip - i_tab, ip->c_magic, ip->c_dev, ip->c_num,
			ip->c_node.i_mode, ip->c_node.i_nlink,
			DEVNUM(ip), ip->c_refs, ip->c_dirty);
		++ip;
	}
}

/* _pdump() dumps state of all processes
 */
STATIC void _pdump(VOID) {
	register ptptr pp = ptab;

	kprintf("Proc:\tSTATUS\tWAIT\tPID\tPPTR\tALARM\tPENDING\tIGNORED\tBREAK\tSP\n");
	while (pp < ptab + PTABSIZE) {
		kprintf("#%d\t%d\t%p\t%d\t%d\t%d\t%p\t%p\t%p\t%p\n",
			pp - ptab, pp->p_status, pp->p_wait, pp->p_pid,
			pp->p_pptr - ptab, pp->p_alarm, pp->p_pending,
			pp->p_ignored, pp->p_break, pp->p_sp);
		++pp;
	}
}

/* idump() dumps state of all system datas
 */
GBL void idump(VOID) {
	kprintf("%s: Errno %d, root #%d, Insys=%d, ptab #%d, callno=%d, cwd #%d, usp %p\n",
		udata.u_name,
		udata.u_error, root_ino - i_tab,
		udata.u_insys, udata.u_ptab - ptab,
		udata.u_callno, udata.u_cwd - i_tab,
		udata.u_ptab->p_sp);
	_idump();
	_pdump();
	bufdump();
}
#endif

/*
 */
STATIC void __itoa (unsigned value, char *strP, uchar radix) {
	char buf[34];
	register char *_di = strP, *_si = buf;
	uchar len;

	do {
		*_si++ = (char)(value % radix);
		value /= radix;
	} while (value != 0);
	/* The value has now been reduced to zero and the
	 * digits are in the buffer.
	 */
	/* The digits in the buffer must now be copied in reverse order into
	 *  the target string, translating to ASCII as they are moved.
	 */
	len = (uchar)(_si-buf);
	while (len != 0) {
		--len;
		radix = (uchar)*--_si;
		*_di++ = (char)((uchar)radix + (((uchar)radix < 10) ? '0' : 'A'-10));
	}
	/* terminate the output string with a zero. */
	*_di ='\0';
}

/*
 */
GBL char *itoa(value, strP, radix)
	register int value;
	char *strP;
	int radix;
{
	char *p = strP;

	if (radix == 0) {
		if (value < 0) {
			*p++ = '-';
			value = -value;
		}
		radix = 10;
	}
	__itoa((unsigned)value,p,(unsigned)radix);
	return strP;
}

/* Short version of printf for printing to kernel */
GBL void kprintf(fmt)
	char *fmt;
{
	register int base;
	uchar l, w, c, pad, s[7], *p, *q, **arg = (uchar **)&fmt + 1;
	int len = 0;

	while ((w = (uchar)*fmt++) != 0) {
		if (w != '%') {
			kputchar(w);
			continue;
		}
		pad = (uchar)(*fmt == '0' ? '0' : ' ');
		w = 0;
		while (*fmt >= '0' && *fmt <= '9') {
			w *= 10;
			w += (uchar)(*fmt - '0');
			++fmt;
		}
		s[1] = 0;
		p = s;
		len = 0x7FFF;
		switch (c = (uchar)*fmt++) {
		case 'c':
			s[0] = *(uchar *)arg++;
			break;
		case 'd': base = 0;	goto prt;
		case 'o': base = 8;	goto prt;
		case 'b': base = 2;	goto prt;
		case 'u': base = 10;	goto prt;
		case 'p':
			w = 4;
			pad = '0';
		case 'x':
			base = 16;
prt:			itoa(*(int *)arg++, (char *)s, base);
			break;
		case 'n':
			p = *arg++;
			len = *(int *)arg++;
			break;
		case 's':
			p = *arg++;
			break;
		default:
			s[0] = c;
			break;
		}
		if (w) {
			l = 0;
			q = p;
			while (--len != 0 && *q++ != 0)
				++l;
			w -= l;
			while ((int)w-- > 0)
				kputchar(pad);
		}
		kputs((char *)p);
	}
}

#ifndef bcopy
#ifndef PC_HOSTED
#ifndef MSX_HOSTED
/* Copy source to destination */
GBL void bcopy(src, dst, count)
	register void *src, *dst;
	uint count;
{
	while (count-- != 0)
		*((uchar *)dst)++ = *((uchar *)src)++;
}

/* Zeroing the memory area */
GBL void bzero(ptr,count)
	register void *ptr;
	register uint count;
{
	while (count-- != 0)
		*((uchar *)ptr)++ = '\0';
}

/* Filling the memory area */
GBL void bfill(ptr,val,count)
	register void *ptr;
	uchar val;
	register uint count;
{
	while (count-- != 0)
		*((uchar *)ptr)++ = val;
}
#endif /* MSX_HOSTED */
#endif /* PC_HOSTED */
#endif /* bcopy */

#ifdef __KERNEL__

extern char *disp_names[];

/* unix() is the system calls dispatcher */
GBL long unix(uint callno, ... /* arg1, arg2, arg3, arg4*/)
/*	register uchar callno; */
/*	uint arg1, arg2, arg3, arg4; */
{
	uint *ap = (uint *)(((char *)&callno) + sizeof(callno));
#if DEBUG > 1
	if ((uint)udata.u_break+256 > (uint)ap)
		panic("PID #%d: stack grows to data (%x/%x)\n",
			udata.u_ptab->p_pid, ap, udata.u_break);
#endif
	if ((uchar)callno > dtsize) {
		udata.u_error = EINVFNC;
		return -1;
	}
	udata.u_argn1 = ap[0]; /*arg1*/
	udata.u_argn2 = ap[1]; /*arg2*/
	udata.u_argn3 = ap[2]; /*arg3*/
	udata.u_argn4 = ap[3]; /*arg4*/
	udata.u_callno = (uchar)callno;
	udata.u_insys++;
	udata.u_error = 0;
	_ei();
#if DEBUG > 0
	tty_poll();
	clk_int();
#endif
#if DEBUG > 1
	if (traceon || udata.u_traceme)
		kprintf("\t\t%4d %s(%p=\"%n\", %p, %p, %p)\n",
			udata.u_ptab->p_pid, disp_names[udata.u_callno],
			ap[0], ap[0] < 0x100 ? "" : (char *)ap[0], 
			12, ap[1], ap[2], ap[3]);
#endif
	/* Branch to correct routine */
	udata.u_retval = (*disp_tab[udata.u_callno])();
#if DEBUG > 1
	if (traceon || udata.u_traceme)
		kprintf("\t\t%4d\t%s() ret %p, err %d\n",
			udata.u_ptab->p_pid, disp_names[udata.u_callno],
			udata.u_retval, udata.u_error);
#endif
	chksigs();
	_di();
	if (runticks >= MAXTICKS) {
		udata.u_ptab->p_status = P_READY;
		swapout();
	}
	_ei();
	if (--udata.u_insys == 0)
		calltrap();	/* Call trap routine if necessary */
	return unixret();
}
#endif /* __KERNEL__ */
