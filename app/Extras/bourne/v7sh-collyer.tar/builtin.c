#include "defs.h"

int
builtin(int argn, char **com)
{
	USED(argn); USED(com);
	return 0;
}
